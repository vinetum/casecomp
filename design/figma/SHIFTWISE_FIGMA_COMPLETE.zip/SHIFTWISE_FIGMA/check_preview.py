from playwright.sync_api import sync_playwright
from pathlib import Path
import json
P=Path(__file__).parent
(P/'previews').mkdir(exist_ok=True)
frames=json.loads((P/'SCREEN_INDEX.json').read_text())
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1520,'height':1000},device_scale_factor=1)
 for f in frames:
  id=f['id'];page.set_content('<html><body style="margin:0">'+(P/'svg'/f'{id}.svg').read_text()+'</body></html>')
  page.locator('body > svg').screenshot(path=str(P/'previews'/f'{id}.png'))
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((P/'PREVIEW.html').read_text())
 assert page.locator('#screen').input_value()=='command'
 page.locator('[data-frame-link="demand"]').first.click()
 assert page.locator('#screen').input_value()=='demand'
 for f in frames:
  page.evaluate('id=>show(id)',f['id'])
  assert page.locator('#canvas > svg').count()==1
 assert not errors,errors
 print(json.dumps({'screens_rendered':len(frames),'navigation_test_passed':True,'javascript_errors':errors}))
 browser.close()
