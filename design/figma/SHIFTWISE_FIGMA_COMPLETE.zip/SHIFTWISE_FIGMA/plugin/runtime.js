/* SHIFTWISE native Figma builder. Concatenate after `const DESIGN = {...};`.
   This local-only development plugin performs no network requests. */
(async function () {
  const warnings = [];
  const targets = new Map();
  const links = [];
  const tokenPaint = new Map();
  const tokenVariable = new Map();
  const textStyles = new Map();
  const builtPages = [];
  const nativeComponents = new Map();
  const pluginMarker = 'shiftwise-design-package-v1';
  let selectedFonts = {};

  const rgba = value => {
    let h = String(value || '#FFFFFF').replace('#', '');
    if (h.length === 3) h = h.split('').map(c => c + c).join('');
    if (!/^[0-9a-fA-F]{6}([0-9a-fA-F]{2})?$/.test(h)) throw new Error('Invalid color: ' + value);
    return {r: parseInt(h.slice(0, 2), 16) / 255, g: parseInt(h.slice(2, 4), 16) / 255,
      b: parseInt(h.slice(4, 6), 16) / 255, a: h.length === 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1};
  };
  const hexKey = value => {
    const c = rgba(value);
    return [c.r, c.g, c.b, c.a].map(v => Math.round(v * 255)).join(',');
  };
  function paint(value) {
    const c = rgba(value);
    let p = {type: 'SOLID', color: {r: c.r, g: c.g, b: c.b}, opacity: c.a};
    const variable = tokenVariable.get(hexKey(value));
    if (variable && figma.variables && figma.variables.setBoundVariableForPaint) {
      p = figma.variables.setBoundVariableForPaint(p, 'color', variable);
    }
    return p;
  }
  const finite = (v, fallback) => Number.isFinite(Number(v)) ? Number(v) : fallback;
  function size(node, width, height) { node.resize(Math.max(0.01, finite(width, 100)), Math.max(0.01, finite(height, 100))); }
  function setRadius(node, radius) {
    if ('cornerRadius' in node) node.cornerRadius = Math.max(0, Math.min(finite(radius, 0), node.width / 2, node.height / 2));
  }
  function position(node, spec) {
    node.x = finite(spec.x, 0); node.y = finite(spec.y, 0);
    if (spec.opacity !== undefined) node.opacity = Math.max(0, Math.min(1, Number(spec.opacity)));
    if (spec.visible !== undefined) node.visible = !!spec.visible;
    if (spec.name) node.name = spec.name;
    if (spec.id) targets.set(spec.id, node);
    if (spec.link) links.push({node, target: spec.link});
  }
  async function fills(node, fill) {
    node.fills = fill ? [paint(fill)] : [];
    const id = fill && tokenPaint.get(hexKey(fill));
    if (id && node.setFillStyleIdAsync) await node.setFillStyleIdAsync(id);
  }
  function strokes(node, spec) {
    if (spec.stroke) {
      node.strokes = [paint(spec.stroke)];
      node.strokeWeight = Math.max(0.01, finite(spec.strokeWidth, 1));
      if ('strokeAlign' in node) node.strokeAlign = 'INSIDE';
    } else node.strokes = [];
  }
  function fontWeight(font) {
    const s = font.style.toLowerCase().replace(/\s+/g, '');
    if (s.includes('extrabold') || s.includes('heavy') || s.includes('black')) return 800;
    if (s.includes('semibold') || s.includes('demibold')) return 600;
    if (s.includes('bold')) return 700;
    if (s.includes('medium')) return 500;
    if (s.includes('light')) return 300;
    return 400;
  }
  async function loadFonts() {
    const available = (await figma.listAvailableFontsAsync()).map(f => f.fontName);
    let family = 'Inter';
    let choices = available.filter(f => f.family === family && !/italic/i.test(f.style));
    if (!choices.length) {
      family = 'Roboto'; choices = available.filter(f => f.family === family && !/italic/i.test(f.style));
      warnings.push('Inter was unavailable: Roboto substituted. Install Inter and rerun for intended typography.');
    }
    if (!choices.length) throw new Error('Inter and Roboto are unavailable. Install Inter or enable Figma fonts before running.');
    for (const weight of [400, 500, 600, 700]) {
      const chosen = [...choices].sort((a, b) => Math.abs(fontWeight(a) - weight) - Math.abs(fontWeight(b) - weight))[0];
      selectedFonts[weight] = chosen;
      await figma.loadFontAsync(chosen);
    }
  }
  async function makeStyles() {
    let collection;
    if (figma.variables && figma.variables.createVariableCollection) {
      collection = figma.variables.createVariableCollection('SHIFTWISE / Color tokens');
    }
    for (const [name, value] of Object.entries(DESIGN.colors || {})) {
      const normalizedName = name.replace(/\./g, '/');
      if (collection) {
        const variable = figma.variables.createVariable(normalizedName, collection, 'COLOR');
        variable.setValueForMode(collection.defaultModeId, rgba(value));
        if (!tokenVariable.has(hexKey(value))) tokenVariable.set(hexKey(value), variable);
      }
      const style = figma.createPaintStyle();
      style.name = 'SHIFTWISE / ' + normalizedName;
      style.paints = [paint(value)];
      if (!tokenPaint.has(hexKey(value))) tokenPaint.set(hexKey(value), style.id);
    }
    const types = [
      ['Display', 40, 700, 48], ['Heading 1', 30, 700, 38], ['Heading 2', 24, 600, 32],
      ['Heading 3', 20, 600, 28], ['Metric', 36, 600, 44], ['Body', 14, 400, 22],
      ['Body strong', 14, 600, 22], ['Label', 12, 600, 18], ['Caption', 11, 400, 16],
      ['Button', 14, 600, 20]
    ];
    for (const [name, fontSize, weight, lineHeight] of types) {
      const style = figma.createTextStyle();
      style.name = 'SHIFTWISE / ' + name; style.fontName = selectedFonts[weight];
      style.fontSize = fontSize; style.lineHeight = {unit: 'PIXELS', value: lineHeight};
      textStyles.set(fontSize + ':' + weight, style.id);
    }
  }
  async function render(spec, parent) {
    let node;
    if (spec.componentKey && nativeComponents.has(spec.componentKey)) {
      node = nativeComponents.get(spec.componentKey).createInstance(); parent.appendChild(node);
      if (spec.width && spec.height) size(node, spec.width, spec.height);
      const textSpec = (spec.children || []).find(c => c.type === 'text') || {};
      const replacement = spec.label !== undefined ? spec.label : textSpec.text;
      const label = node.findOne(n => n.type === 'TEXT');
      if (label) {
        if (replacement !== undefined) label.characters = String(replacement);
        if (textSpec.fontSize !== undefined) label.fontSize = finite(textSpec.fontSize, 13);
        if (textSpec.lineHeight !== undefined) label.lineHeight = {unit: 'PIXELS', value: finite(textSpec.lineHeight, 20)};
      }
    } else if (spec.type === 'group' || spec.type === 'frame' || spec.type === 'button') {
      node = figma.createFrame(); parent.appendChild(node); size(node, spec.width, spec.height);
      node.name = spec.name || 'Group'; node.clipsContent = !!spec.clip;
      await fills(node, spec.fill); strokes(node, spec); setRadius(node, spec.radius);
      for (const child of spec.children || []) await render(child, node);
      if (spec.layout) {
        const layout = typeof spec.layout === 'string' ? {direction: spec.layout} : spec.layout;
        node.layoutMode = layout.direction === 'HORIZONTAL' ? 'HORIZONTAL' : 'VERTICAL';
        node.primaryAxisSizingMode = layout.hug ? 'AUTO' : 'FIXED';
        node.counterAxisSizingMode = layout.hugCross ? 'AUTO' : 'FIXED';
        node.itemSpacing = finite(layout.gap, 8);
        const padding = finite(layout.padding, 0);
        node.paddingTop = finite(layout.paddingTop, padding); node.paddingBottom = finite(layout.paddingBottom, padding);
        node.paddingLeft = finite(layout.paddingLeft, padding); node.paddingRight = finite(layout.paddingRight, padding);
        node.primaryAxisAlignItems = layout.align === 'CENTER' ? 'CENTER' : layout.align === 'SPACE_BETWEEN' ? 'SPACE_BETWEEN' : 'MIN';
        node.counterAxisAlignItems = layout.crossAlign === 'CENTER' ? 'CENTER' : 'MIN';
      }
    } else if (spec.type === 'rect') {
      node = figma.createRectangle(); parent.appendChild(node); size(node, spec.width, spec.height);
      await fills(node, spec.fill); strokes(node, spec); setRadius(node, spec.radius);
    } else if (spec.type === 'text') {
      node = figma.createText(); parent.appendChild(node);
      const weight = [400, 500, 600, 700].includes(spec.fontWeight) ? spec.fontWeight : 400;
      const fontSize = finite(spec.fontSize, 14);
      node.fontName = selectedFonts[weight]; node.fontSize = fontSize;
      const textStyle = textStyles.get(fontSize + ':' + weight);
      if (textStyle) await node.setTextStyleIdAsync(textStyle);
      node.characters = String(spec.text === undefined ? '' : spec.text);
      node.lineHeight = {unit: 'PIXELS', value: finite(spec.lineHeight, Math.ceil(fontSize * 1.45))};
      node.textAlignHorizontal = ['CENTER', 'RIGHT', 'JUSTIFIED'].includes(spec.align) ? spec.align : 'LEFT';
      node.textAutoResize = 'HEIGHT';
      node.resize(Math.max(1, finite(spec.width, 200)), Math.max(1, finite(spec.height, fontSize * 1.5)));
      await fills(node, spec.fill || '#142F34');
    } else if (spec.type === 'line') {
      node = figma.createLine(); parent.appendChild(node);
      const dx = finite(spec.x2, 100) - finite(spec.x, 0), dy = finite(spec.y2, 0) - finite(spec.y, 0);
      node.resize(Math.max(0.01, Math.sqrt(dx * dx + dy * dy)), 0);
      node.rotation = -Math.atan2(dy, dx) * 180 / Math.PI;
      node.strokes = [paint(spec.stroke || '#DDE6E7')]; node.strokeWeight = finite(spec.strokeWidth, 1);
    } else if (spec.type === 'svg') {
      node = figma.createNodeFromSvg(spec.svg); parent.appendChild(node); size(node, spec.width, spec.height);
    } else throw new Error('Unknown scene node type: ' + spec.type);
    position(node, spec);
    node.setPluginData('shiftwiseSource', pluginMarker);
    return node;
  }
  async function componentLabel(parent, text, color = '#FFFFFF', sizeValue = 14) {
    const label = figma.createText(); label.fontName = selectedFonts[600]; label.fontSize = sizeValue;
    label.characters = text; label.lineHeight = {unit: 'PIXELS', value: Math.max(20, Math.ceil(sizeValue * 1.25))}; label.fills = [paint(color)];
    parent.appendChild(label); return label;
  }
  async function makeComponents(page) {
    const t = {
      ink: DESIGN.colors.ink || '#142F34', muted: DESIGN.colors.muted || '#60777E',
      primary: DESIGN.colors.primary || '#147D73', hover: DESIGN.colors.navHi || '#0C625A',
      soft: DESIGN.colors.soft || '#EEF1F4', border: DESIGN.colors.border || '#DDE6E7',
      mint: DESIGN.colors.mint || '#E8F5EE', amberBg: DESIGN.colors.amberBg || '#FFF0DD',
      amber: DESIGN.colors.amber || '#92591D', redBg: DESIGN.colors.redBg || '#FCECEC',
      red: DESIGN.colors.red || '#A34141', blue: DESIGN.colors.blue || '#456B7B',
      white: DESIGN.colors.white || '#FFFFFF'
    };
    const heading = await render({type:'text',x:0,y:0,width:1100,fontSize:30,fontWeight:700,
      text:'SHIFTWISE / Component library',fill:t.ink},page);
    await render({type:'text',x:0,y:52,width:1100,fontSize:14,text:'Reusable native variants, auto-layout, token-bound fills and editable typography. Samples are interface states, not business results.',fill:t.muted},page);
    const sections = [
      {name:'Button', y:120, variants:[['Primary / Default',t.primary,t.white,'Recalculate'],['Primary / Hover',t.hover,t.white,'Recalculate'],['Primary / Loading',t.soft,t.muted,'Calculating…'],['Primary / Disabled',t.border,t.muted,'Recalculate'],['Secondary / Default',t.white,t.ink,'Restore assumptions']]},
      {name:'Status', y:410, variants:[['State / Feasible',t.mint,t.primary,'Feasible'],['State / Conflict',t.amberBg,t.amber,'Minimum conflict'],['State / Processing',t.soft,t.blue,'Computing'],['State / Error',t.redBg,t.red,'Calculation failed'],['State / Reference',t.soft,t.muted,'Official reference']]},
      {name:'Scenario', y:680, variants:[['State / Base',t.primary,t.white,'BASE'],['State / Peak',t.mint,t.primary,'PEAK'],['State / Disrupt',t.amberBg,t.amber,'DISRUPT']]}
    ];
    for (const section of sections) {
      await render({type:'text',x:0,y:section.y,width:900,fontSize:20,fontWeight:600,text:section.name,fill:t.ink},page);
      const components=[];
      for (let i=0;i<section.variants.length;i++) {
        const [variant,bg,fg,label] = section.variants[i];
        const c=figma.createComponent(); page.appendChild(c); c.name='Variant='+variant;
        c.layoutMode='HORIZONTAL'; c.primaryAxisSizingMode='AUTO';c.counterAxisSizingMode='AUTO';
        c.paddingLeft=16;c.paddingRight=16;c.paddingTop=10;c.paddingBottom=10;c.itemSpacing=8;
        c.primaryAxisAlignItems='CENTER';c.counterAxisAlignItems='CENTER';c.cornerRadius=8;
        c.fills=[paint(bg)];
        if (section.name === 'Button' && variant.startsWith('Secondary')) { c.strokes=[paint(t.border)];c.strokeWeight=1; }
        await componentLabel(c,label,fg,section.name === 'Button' ? 13 : 14);c.x=i*250;c.y=section.y+50;
        c.description=section.name+' variant. Replace labels or colors via native Figma properties/styles; no modeled result is embedded.';
        const keys = section.name === 'Button' ? ['button.primary','button.hover','button.loading','button.disabled','button.secondary'] :
          section.name === 'Status' ? ['status.feasible','status.conflict','status.processing','status.error','status.reference'] :
          ['scenario.base','scenario.peak','scenario.disrupt'];
        nativeComponents.set(keys[i], c);
        if (keys[i] === 'button.primary') nativeComponents.set('button.small', c);
        components.push(c);
      }
      const set=figma.combineAsVariants(components,page);set.name=section.name;set.x=0;set.y=section.y+50;
      set.description='SHIFTWISE reusable '+section.name.toLowerCase()+' variants. Auto-layout and token-bound fills.';
    }
    const metric=figma.createComponent();page.appendChild(metric);metric.name='Metric card';metric.x=0;metric.y=970;
    metric.layoutMode='VERTICAL';metric.primaryAxisSizingMode='AUTO';metric.counterAxisSizingMode='FIXED';
    metric.resize(300,160);metric.paddingLeft=24;metric.paddingRight=24;metric.paddingTop=24;metric.paddingBottom=24;metric.itemSpacing=8;
    metric.cornerRadius=14;metric.fills=[paint(t.white)];metric.strokes=[paint(t.border)];
    await componentLabel(metric,'Metric label',t.muted,12);await componentLabel(metric,'—',t.ink,36);
    await componentLabel(metric,'Scope and qualification',t.muted,12);
    nativeComponents.set('metric', metric);
    metric.description='Replace the em dash with a verified value and preserve the metric scope. Sample intentionally contains no invented result.';
    await render({type:'text',x:350,y:995,width:700,fontSize:14,text:'Production binding: replace sample text with source-verified metrics. Use the correct warehouse/date/shift or official-week scope. Desktop screen layers are explicitly named and independently editable.',fill:t.muted},page);
  }
  function containingPage(node) { let p=node;while(p && p.type!=='PAGE')p=p.parent;return p; }

  try {
    if (typeof DESIGN !== 'object' || !Array.isArray(DESIGN.pages)) throw new Error('Design scene data is missing. Run the packaged code.js, not runtime.js by itself.');
    await loadFonts();
    await makeStyles();
    const library=figma.createPage();library.name='03 · Foundations & components';builtPages.push(library);
    await figma.setCurrentPageAsync(library);await makeComponents(library);
    let firstFrame;
    let commandFrame;
    let screenFrameCount=0;
    for (const pageSpec of DESIGN.pages) {
      const page=pageSpec.name === library.name ? library : figma.createPage();
      page.name=pageSpec.name;page.setPluginData('shiftwiseSource',pluginMarker);
      if (page !== library) builtPages.push(page);
      await figma.setCurrentPageAsync(page);
      const specs=pageSpec.frames || [];
      // Keep the native component library above the foundations artboards.
      let rowY=page === library ? 1500 : 0;
      for(let base=0;base<specs.length;base+=3) {
        const row=specs.slice(base,base+3);let x=0;let maxHeight=0;
        for(const spec of row) {
          const frame=figma.createFrame();page.appendChild(frame);frame.name=spec.name || spec.id;screenFrameCount++;
          size(frame,spec.width,spec.height);frame.x=x;frame.y=rowY;frame.clipsContent=true;
          await fills(frame,spec.fill || '#F4F7F8');
          frame.setPluginData('shiftwiseSource',pluginMarker);
          if(spec.id)targets.set(spec.id,frame);
          for(const child of spec.children || [])await render(child,frame);
          if(!firstFrame) firstFrame=frame;
          if(!commandFrame && /command.*center/i.test(spec.name || '')) commandFrame=frame;
          if(spec.description)frame.description=spec.description;
          x+=frame.width+100;maxHeight=Math.max(maxHeight,frame.height);
        }
        rowY+=maxHeight+150;
      }
    }
    let linked=0;
    for(const {node,target} of links) {
      const destination=targets.get(target);
      if(!destination) { warnings.push('Unresolved prototype target: '+target);continue; }
      if(containingPage(node)!==containingPage(destination)) { warnings.push('Cross-page navigation skipped: '+target);continue; }
      try {
        await node.setReactionsAsync([{trigger:{type:'ON_CLICK'},actions:[{type:'NODE',destinationId:destination.id,
          navigation:'NAVIGATE',transition:{type:'DISSOLVE',duration:0.2,easing:{type:'EASE_IN_AND_OUT'}},preserveScrollPosition:false}]}]);
        linked++;
      } catch(e) { warnings.push('Prototype link failed '+target+': '+String(e)); }
    }
    firstFrame=commandFrame || firstFrame;
    if(firstFrame) {
      await figma.setCurrentPageAsync(containingPage(firstFrame));
      figma.currentPage.selection=[firstFrame];figma.viewport.scrollAndZoomIntoView([firstFrame]);
      // Define a proper Present-mode starting point, where supported.
      try { figma.currentPage.flowStartingPoints=[{nodeId:firstFrame.id,name:'SHIFTWISE dashboard'}]; } catch(e) { warnings.push('Set the first prototype flow manually if needed.'); }
    }
    const unique=[...new Set(warnings)];
    console.log('SHIFTWISE import complete:',{pages:builtPages.length,screenFrames:screenFrameCount,namedTargets:targets.size,prototypeLinks:linked,warnings:unique});
    figma.notify('SHIFTWISE created: '+builtPages.length+' pages, '+screenFrameCount+' screens, '+linked+' prototype links'+(unique.length?' · see plugin console for '+unique.length+' notes':''),{timeout:10000});
    figma.closePlugin(unique.length ? 'Design created. '+unique.join(' | ') : 'SHIFTWISE design created successfully.');
  } catch(error) {
    console.error(error);
    figma.closePlugin('SHIFTWISE import stopped: '+String(error)+'. Any created layers remain editable; undo or delete new pages before retrying.');
  }
})();
