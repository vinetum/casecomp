# SHIFTWISE native Figma import

This package creates real, editable Figma layers in a design file: screens, text, charts, color variables/styles, typography styles, component variants, and prototype navigation. It is not a fabricated `.fig` binary or an already-created file in your Figma account. The code runs locally through Figma's development-plugin feature and makes no network requests.

## Import once — no code editing required

1. Unzip the complete package into a permanent folder on your Mac.
2. Open the **Figma desktop application**, sign in, and create a **new Figma Design file** in Drafts. Use a blank file so the generated pages are easy to identify. This is a Design file, not FigJam or a Figma Slides presentation.
3. Open Figma's main menu → **Plugins → Development → Import plugin from manifest…**. Depending on Figma's version, development plugins may appear under **Plugins → Development** or the plugin-management menu. Development-plugin import is available in the desktop app; the website alone may not expose this command.
4. Select **plugin/manifest.json** from this unzipped folder. Keep `manifest.json` beside `code.js`; importing only the manifest without the packaged code will fail.
5. Run **Plugins → Development → SHIFTWISE — Complete Dashboard Design**. Wait for the completion message. Large files can take a moment while native text, variables, and frames are created.
6. The initial dashboard is selected. Browse the generated pages and use **Present** to follow linked navigation. The **03 · Foundations & components** page contains reusable variants; color and text styles are in local styles, and color tokens are also native variables.
7. Rename the Figma file **SHIFTWISE — Workforce Intelligence**. Figma saves it in your account. Share the actual link from Figma's **Share** button if desired; no public link exists until you create/share that file.

The plugin adds new pages and local styles. Run it once in a blank file. Rerunning adds another copy; it does not merge or overwrite your earlier work. If you need a clean retry, use a new blank design file or undo/delete the newly generated pages and styles.

## What remains editable

- Text is native Figma text, not a screenshot.
- Cards, controls, panels, status chips, chart marks, tables, and layout containers are native layers.
- Shared colors use local paint styles and, when supported, native color variables.
- The reusable library includes native button, scenario, and status variants plus an auto-layout metric-card component.
- Main screen frames preserve deliberate art direction with positioned layers; component internals use auto layout. Screen layers are not claimed to be fully responsive production code.
- Prototype links navigate between frames on the same page. Links across different pages are intentionally skipped with a console note because normal Figma frame navigation is page-scoped.

## Prototype, not a second application

The design is a visual prototype grounded in the audited application. It does not execute Python, retrain models, solve staffing, download the validated submission, enforce authentication, or dynamically calculate slider values. Those features remain in the real SHIFTWISE app. A prototype click can navigate to a prepared source-backed screen; it is never presented as a live calculation.

## Fonts and troubleshooting

The intended font is **Inter**. The plugin uses the available Inter Regular/Medium/Semi Bold/Bold styles. If Inter is unavailable it uses Roboto and reports that substitution. If neither font is available, install Inter or enable Figma fonts and retry. Your Figma account's font access and desktop plugin permissions are outside this package.

The plugin declares no network access. It needs access only to the currently open design document. If your organization blocks development plugins, use a personal Draft where permitted or import the supplied SVG screens instead. SVG fallback preserves editable vector shapes, but may not retain native text, variables, components, or prototype links as fully as the plugin.

## Verification scope

JavaScript syntax and package structure can be checked locally. Executing the plugin inside Figma and checking Figma account persistence requires an actual Figma session; do not mistake a local browser preview for proof of native Figma import. The creation completion message and plugin console report import counts and any unresolved links/font substitutions. Check that message after importing.
