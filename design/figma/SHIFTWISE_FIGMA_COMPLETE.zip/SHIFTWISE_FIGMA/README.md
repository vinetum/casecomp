# SHIFTWISE — Complete Dashboard Design

A source-grounded, editable Figma import package with **39 artboards**, three pages, native components, semantic color variables/styles, typography styles and prototype links. This is a design deliverable for the existing SHIFTWISE application; it does not replace or modify the audited app.

## Open and import

1. Unzip this package.
2. Open **PREVIEW.html** to review all screens offline in your browser. Use the screen picker or click navigation/linked controls. The preview needs no account, server or installation.
3. Open **Figma desktop → New Design file** in your Drafts.
4. Choose **Plugins → Development → Import plugin from manifest…** and select **plugin/manifest.json**.
5. Run **SHIFTWISE — Complete Dashboard Design** from Development plugins. No code editing or credentials are required.
6. Wait for completion, then use Present on the selected desktop Command Center. Rename/save the file and use Figma's Share button for your real account link.

Detailed instructions and font/permission troubleshooting: **README_IMPORT.md**. Keep the manifest and code.js together. Run once in a blank file; a second run adds duplicate content.

## What is included

### 01 · Desktop workspace — 32 artboards

- All five main screens: Command Center, Demand Intelligence, Staffing Optimizer, Scenario Lab, Decision & Export.
- BASE, PEAK and DISRUPT official weekly comparisons.
- Service First, Balanced and Budget Conscious examples with truthful mode selection.
- Last Worker beneficial addition and no-beneficial-change outcome, including lender effects and costs.
- Feasibility Certificate showing local allocation, outgoing lending, incoming borrowing, overtime and qualification limits. A lent worker is visibly committed, not idle.
- Actual forecast, backtest, calibration and historical demand visualizations.
- Four BASE frontier allocations and three Last Worker-context frontier allocations, each linked to the matching source-backed preview.
- Pending scenario inputs, loading, timeout/reference, minimum-conflict template, source-closed block, protected login, export-ready and export-error states.
- Expanded assumptions/evidence.
- Five guided-demo artboards, with Next, Reset and Exit links.

### 02 · Responsive — 5 artboards

- Tablet Command Center.
- Mobile Command Center, Scenario Lab and Decision & Export.
- Mobile guided BASE scene.

### 03 · Foundations & components — 2 artboards plus native library

- Semantic palette, typography, spacing, layout and accessibility guidance.
- Interaction map, data scopes, source provenance and state rules.
- Native button/status/scenario variants and reusable metric-card component.
- Local colors, variables and typography styles. Most screen geometry is deliberately positioned; library components use auto layout. Simple screen buttons reuse native instances.

See **SCREEN_INDEX.json** for every artboard ID, name, page and size.

## Review files

- **SHIFTWISE_DESIGN_BOOK.pdf** — all 39 artboards, for review rather than editing.
- **SHIFTWISE_DESIGN_OVERVIEW.png** — selected screen overview.
- **PREVIEW.html** — self-contained clickable local preview.
- **previews/** — PNG review exports.
- **svg/** — individual vector fallback imports. Figma may convert SVG text to outlines; the native plugin preserves actual editable text, styles and components.
- **plugin/** — complete offline Figma development plugin.
- **scene_design.json** — shared declarative design source.
- **source_data.json** — extracted verified metrics/series with provenance.
- **build_design.py**, **check_preview.py**, **validate_design.py** — optional reproduction/verification tools. You do not need to run these to import the design.

## Data integrity and prototype boundaries

All charts and displayed business values use saved audited casecomp artifacts. Week metrics are separately labeled from selected-block metrics. Inputs are simulated; costs are projections; service values are model estimates. The original 567-row submission and application code were not changed.

This Figma prototype does **not** run Python, compute new forecasts, optimize workers, enforce authentication, change slider values dynamically or actually export files. Clicks navigate prepared frames. A minimum-conflict state intentionally omits invented custom numerical results. A source-closed Pharmacy block displays Closed rather than 0% service. Native Figma account execution/persistence and font layout are not verified here because no Figma authoring or desktop-control tool was exposed to this chat, despite the integration being installed.

The local browser preview and a Figma API mock are separate checks, not proof of a successful import in your account. The runtime creates native layers and reports completion or errors in Figma. The included verification reports identify what actually ran.

## Suggested prototype review

Command Center → Demand Intelligence → historical evidence → Staffing Optimizer → Balanced/Budget → Scenario Lab → pending inputs → loading → resolved official reference → Decision & Export → frontier point → corresponding allocation → beneficial Last Worker → guided demo → official export state → assumptions.

No public Figma file link or proprietary .fig file is fabricated. The import creates the real editable file in your own account.
