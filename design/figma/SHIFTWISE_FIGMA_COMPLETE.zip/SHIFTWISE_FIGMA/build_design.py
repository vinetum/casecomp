"""Source-grounded SHIFTWISE scene graph, editable SVGs and Figma plugin input."""
from pathlib import Path
import json, math, html, re
from PIL import ImageFont
P=Path(__file__).parent
C=dict(ink='#16353D',muted='#637D86',subtle='#8B9FA6',nav='#102E35',navHi='#1D4951',primary='#087F75',teal='#19A68E',mint='#E8F6EF',paper='#F5F8FA',white='#FFFFFF',border='#DFE7EB',soft='#EEF3F5',gold='#BD8830',amber='#9B640E',amberBg='#FFF5E3',red='#B54242',redBg='#FFF0EE',blue='#4D7F9F')
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONTB='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
D={'colors':C,'pages':[]}

def txt(x,y,w,text,size=14,weight=400,color='ink',name=None):
 f=ImageFont.truetype(FONTB if weight>=600 else FONT,size)
 lines=[]
 for para in str(text).split('\n'):
  line=''
  for word in para.split():
   candidate=(line+' '+word).strip()
   if line and f.getlength(candidate)>w:
    lines.append(line);line=word
   else:line=candidate
  lines.append(line)
 lh=round(size*1.45,1)
 return dict(type='text',x=x,y=y,width=w,height=max(lh,len(lines)*lh),text='\n'.join(lines),fontSize=size,fontWeight=weight,fill=C.get(color,color),lineHeight=lh,name=name or str(text)[:70])
def rect(x,y,w,h,fill='white',radius=0,stroke=None,name='Surface'):
 d=dict(type='rect',name=name,x=x,y=y,width=w,height=h,fill=C.get(fill,fill),radius=radius)
 if stroke:d['stroke']=C.get(stroke,stroke)
 return d
def line(x,y,x2,y2,color='border',width=1):return dict(type='line',name='Rule',x=x,y=y,x2=x2,y2=y2,stroke=C.get(color,color),strokeWidth=width)
def group(x,y,w,h,children,name='Group',fill=None,radius=0,link=None,stroke=None,**extra):
 d=dict(type='group',name=name,x=x,y=y,width=w,height=h,children=children,**extra)
 if fill:d['fill']=C.get(fill,fill)
 if radius:d['radius']=radius
 if stroke:d['stroke']=C.get(stroke,stroke)
 if link:d['link']=link
 return d
icons={
'command':'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
'demand':'<path d="M4 20h17M6 16V9m6 7V4m6 12v-6"/>',
'optimizer':'<circle cx="9" cy="8" r="3"/><path d="M3 20v-2a6 6 0 0 1 12 0v2M17 4a3 3 0 0 1 0 6m1 4a5 5 0 0 1 3 5"/>',
'scenario':'<path d="M3 6h18M3 12h18M3 18h18"/><circle cx="8" cy="6" r="2"/><circle cx="16" cy="12" r="2"/><circle cx="10" cy="18" r="2"/>',
'decision':'<circle cx="6" cy="5" r="2"/><circle cx="18" cy="5" r="2"/><circle cx="6" cy="19" r="2"/><path d="M6 7v10M18 7v3a5 5 0 0 1-5 5H6"/>',
'check':'<path d="m5 12 4 4L19 6"/>', 'arrow':'<path d="M4 12h15m-6-6 6 6-6 6"/>',
'play':'<path d="m8 4 12 8-12 8Z"/>', 'lock':'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
'download':'<path d="M12 3v12m-5-5 5 5 5-5M4 17v4h16v-4"/>',
'warn':'<path d="m12 3 10 18H2Z"/><path d="M12 9v5m0 3v1"/>',
'pulse':'<path d="M2 12h5l3-9 4 18 3-9h5"/>',
'help':'<circle cx="12" cy="12" r="9"/><path d="M9 8a3 3 0 1 1 4 3c-1 1-1 1-1 3m0 3v1"/>',
'chevron':'<path d="m8 4 8 8-8 8"/>',
}
def icon(x,y,name='command',size=20,color='muted'):
 svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="{C.get(color,color)}" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">{icons.get(name,icons["command"])}</svg>'
 return dict(type='svg',name='Icon / '+name,x=x,y=y,width=size,height=size,svg=svg)
def btn(x,y,w,label,kind='primary',link=None,ic=None,h=40):
 fill='primary' if kind=='primary' else 'white';color='white' if kind=='primary' else 'ink'
 label_width=w-(32 if not ic else 55)
 font_size=13
 while font_size>10 and ImageFont.truetype(FONTB,font_size).getlength(label)>label_width:font_size-=1
 ch=[txt(16 if not ic else 43,(h-20)/2,label_width,label,font_size,600,color)]
 if ic:ch.insert(0,icon(15,(h-18)/2,ic,18,color))
 return group(x,y,w,h,ch,'Button / '+label,fill,8,link,'border' if kind!='primary' else None,componentKey='button/'+kind)
def badge(x,y,label,tone='good',w=None):
 w=w or max(78,len(label)*7+29);bg='mint' if tone=='good' else ('amberBg' if tone=='warn' else 'soft');fg='primary' if tone=='good' else ('amber' if tone=='warn' else 'muted')
 return group(x,y,w,28,[icon(8,7,'check' if tone=='good' else ('warn' if tone=='warn' else 'pulse'),14,fg),txt(29,4,w-35,label,11,600,fg)],'Badge / '+label,bg,14)
def card(x,y,w,h,title=None,kicker=None,sub=None):
 ch=[]
 if kicker:ch.append(txt(24,21,w-48,kicker.upper(),10,600,'muted'))
 if title:ch.append(txt(24,40 if kicker else 22,w-48,title,19,600))
 if sub:ch.append(txt(24,73 if kicker else 53,w-48,sub,12,400,'muted'))
 return group(x,y,w,h,ch,title or 'Card','white',12,stroke='border')
def add(card,*nodes):card['children'].extend(nodes);return card
def metric(x,y,w,label,value,note,tone='ink'):
 return group(x,y,w,138,[txt(20,19,w-40,label,12,500,'muted'),txt(20,46,w-40,value,32,600,tone),txt(20,99,w-40,note,11,400,'muted')],'Metric / '+label,'white',12,stroke='border')
NAV=[('command','Command Center'),('demand','Demand Intelligence'),('optimizer','Staffing Optimizer'),('scenario','Scenario Lab'),('decision','Decision & Export')]

def shell(id,title,sub,h=1240,active='command',scenario='BASE',context='Feb 14, 2026',shift='MID',mode='Service First',guide=False):
 ch=[rect(0,0,1440,h,'paper'),rect(0,0,224,h,'nav'),rect(224,0,1216,72,'white'),line(224,72,1440,72)]
 ch += [rect(24,27,36,36,'navHi',10),icon(30,34,'pulse',24,'#70D2BD'),txt(71,26,140,'SHIFTWISE',19,700,'white'),txt(72,52,130,'WORKFORCE RESILIENCE',7,500,'#AEC7CD'),txt(24,110,180,'OPERATIONS WORKSPACE',9,600,'#84A5AE')]
 for i,(key,label) in enumerate(NAV):
  y=143+i*57
  b=group(14,y,196,46,[icon(14,13,key,20,'#A9DCD5' if active==key else '#90ADB5'),txt(44,13,144,label,12,600 if active==key else 400,'white' if active==key else '#B2CBD1')], 'Navigation / '+label,'navHi' if active==key else None,8,key)
  ch.append(b)
 ch += [txt(24,490,160,'THE FORGE FRAMEWORK',9,600,'#84A5AE')]
 for i,(letter,label) in enumerate(zip('FORGE',['Forecast demand','Optimize staffing','Reallocate resources','Guard service','Evaluate outcomes'])):
  ch += [txt(25,527+i*34,20,letter,11,600,'#76B8B4'),txt(51,526+i*34,155,label,11,400,'#B2CBD1')]
 ch += [line(24,733,200,733,'#315058'),icon(24,758,'help',18,'#90ADB5'),txt(52,758,147,'Assumptions & evidence',10,500,'#B2CBD1')]
 ch.append(group(20,750,184,42,[],'Open evidence',link='evidence'))
 ch += [txt(24,h-70,177,'SIMULATED COMPETITION DATA',8,600,'#84A5AE'),txt(24,h-49,175,'Estimates. Not guarantees.',10,400,'#B2CBD1')]
 ch += [txt(256,26,615,'WORKFORCE PLANNING  /  FEB 12–18, 2026',10,600,'muted'),badge(1110,22,'Engine ready',w=124),btn(1250,18,158,'Lock demo','secondary','login','lock',36)]
 ch += [txt(256,105,730,title,32,700),txt(256,154,770,sub,14,400,'muted'),btn(1220,113,188,'Start guided demo','secondary','guide-base','play')]
 controls=group(256,207,1152,82,[],'Context selectors','white',12,stroke='border')
 for j,(lab,val,w) in enumerate([('Warehouse','02 · Large',205),('Date',context,205),('Shift',shift,146),('Department','Front End',190)]):
  x=[22,235,448,602][j];add(controls,txt(x,15,w-28,lab,10,500,'muted'),txt(x,39,w-35,val,13,600),icon(x+w-28,39,'chevron',14))
  if j<3:add(controls,line(x+w-5,16,x+w-5,65))
 for j,label in enumerate(['BASE','PEAK','DISRUPT']):
  x=815+j*105;sel=scenario==label
  add(controls,group(x,23,98,36,[txt(13,9,80,label,10,600,'primary' if sel else 'muted')], 'Scenario / '+label,'mint' if sel else None,7,{'BASE':'command','PEAK':'command-peak','DISRUPT':'command-disrupt'}[label]))
 ch.append(controls)
 ch += [txt(256,h-36,1000,'SHIFTWISE  /  Source-backed staffing decisions · All probabilities are modeled estimates.',10,400,'muted')]
 return {'id':id,'name':title+' / '+scenario+' / '+mode,'width':1440,'height':h,'children':ch}

def table(x,y,w,heads,rows,widths=None,row_h=52):
 widths=widths or [w/len(heads)]*len(heads);ch=[rect(0,0,w,36,'soft',6)]
 xs=[0]
 for z in widths:xs.append(xs[-1]+z)
 for i,hd in enumerate(heads):ch.append(txt(xs[i]+12,10,widths[i]-24,hd,10,500,'muted'))
 for ri,row in enumerate(rows):
  yy=36+ri*row_h
  for j,val in enumerate(row):ch.append(txt(xs[j]+12,yy+16,widths[j]-24,str(val),12,600 if j==0 else 400,'ink'))
  ch.append(line(0,yy+row_h,w,yy+row_h))
 return group(x,y,w,36+len(rows)*row_h,ch,'Data table')

def statbox(x,y,w,label,val,note,good=True):
 return group(x,y,w,130,[txt(18,17,w-36,label,11,500,'muted'),txt(18,45,w-36,val,30,600,'primary' if good else 'amber'),txt(18,99,w-36,note,10,400,'muted')],'Stat / '+label,'mint' if good else 'amberBg',10)

def notice(x,y,w,title,body,tone='warn',h=94):
 fg='amber' if tone=='warn' else 'primary';bg='amberBg' if tone=='warn' else 'mint'
 return group(x,y,w,h,[icon(18,21,'warn' if tone=='warn' else 'check',20,fg),txt(50,16,w-70,title,13,600,fg),txt(50,42,w-70,body,12,400,fg)],'Notice / '+title,bg,10)

def pathplot(x,y,w,h,series,labels,ylim=None):
 ch=[];vals=[float(v) for s in series for v in s['values']];maxv=ylim or max(vals)*1.12;N=max(len(s['values']) for s in series)
 for i in range(5):
  yy=h-i*h/4;ch.extend([line(42,yy,w,yy),txt(0,max(0,yy-7),38,str(round(maxv*i/4)),10,400,'muted')])
 for i,lab in enumerate(labels):
  xx=42+(w-70)*i/max(1,len(labels)-1);ch.append(txt(min(w-65,xx-16),h+12,65,lab,10,400,'muted'))
 for s in series:
  p=[(42+(w-70)*i/max(1,N-1),h-h*float(v)/maxv) for i,v in enumerate(s['values'])]
  for a,b in zip(p,p[1:]):ch.append(line(*a,*b,s['color'],2.5))
  for xx,yy in p:ch.append(rect(xx-3,yy-3,6,6,s['color'],3))
 return group(x,y,w,h+35,ch,'Chart / Actual source series')

def allocrows(scene):
 return [[a['department'],a['draft_employees'],a['employees'],a['regular'],a['flex'],a['overtime'],f"{a['probability']*100:.1f}%" if a['probability'] is not None else 'Closed',f"${a['cost']:,.2f}"] for a in scene['plan']['allocations']]

def allocation_table(x,y,w,scene):return table(x,y,w,['Department','Draft','Plan','Regular','Flex','OT','Modeled service','Block cost'],allocrows(scene),[w*.22,w*.06,w*.06,w*.08,w*.06,w*.06,w*.19,w*.27],44)

# The source snapshot is compiled separately from audited existing artifacts.

def command_screen(id='command',scenario='BASE'):
 scene=SCENES[scenario];week=next(s for s in S['weekly_scenarios'] if s['scenario_code']==scenario)
 f=shell(id,'Command Center','Your week, in perspective. Every decision grounded in evidence.',1420,scenario=scenario)
 ch=f['children'];ch.append(txt(256,314,1100,'OFFICIAL PLANNING WEEK · ALL WAREHOUSES · '+scenario,10,600,'muted'))
 for j,(label,value,note,tone) in enumerate([
  ('Projected labor cost',f"${week['cost']:,.0f}",'Official scenario · not realized spending','ink'),
  ('Modeled service attainment',f"{week['modeled_service']*100:.1f}%",'Equal weight across open department blocks','primary'),
  ('Blocks below 95% estimate',str(week['at_risk_blocks']),'Open blocks with remaining modeled risk','amber' if week['at_risk_blocks'] else 'ink'),
  ('Infeasible draft groups',str(week['infeasible_draft_groups']),'Draft conflicts · not recommended-plan conflicts','amber' if week['infeasible_draft_groups'] else 'ink')]):
  ch.append(metric(256+j*292,338,276,label,value,note,tone))
 chart=card(256,500,728,350,'Warehouse 2 · scenario coverage','WORKFORCE OUTLOOK','Employee block assignments per day, not unique weekly people.')
 ds=S['warehouse2_daily_staffing'];maxv=math.ceil(max(r[k] for r in ds for k in ['BASE','PEAK','DISRUPT'])/40)*40
 for i in range(5):
  yy=281-i*43;add(chart,line(64,yy,699,yy),txt(23,yy-6,36,str(round(maxv*i/4)),10,400,'muted'))
 for i,row in enumerate(ds):
  for j,(key,col) in enumerate([('BASE','primary'),('PEAK','#8CB1B2'),('DISRUPT','#D6B56E')]):
   bh=row[key]/maxv*172;add(chart,rect(85+i*86+j*19,281-bh,16,bh,col,3))
  add(chart,txt(86+i*86,296,70,'Feb '+row['day_date'][-2:].lstrip('0'),10,400,'muted'))
 for j,(lab,col) in enumerate([('BASE','primary'),('PEAK','#8CB1B2'),('DISRUPT','#D6B56E')]):add(chart,rect(200+j*110,328,8,8,col,2),txt(214+j*110,323,100,lab,10,500,'muted'))
 ch.append(chart)
 pulse=card(1008,500,400,350,'Pressure changes the plan','SCENARIO PULSE','Official weekly projections · all warehouses')
 for i,row in enumerate(S['weekly_scenarios']):
  yy=107+i*71;key=row['scenario_code'];linkid={'BASE':'command','PEAK':'command-peak','DISRUPT':'command-disrupt'}[key]
  add(pulse,group(15,yy-8,370,65,[txt(12,5,150,key,12,600),txt(12,29,185,f"{row['modeled_service']*100:.1f}% modeled service",11,400,'muted'),txt(220,6,132,f"${row['cost']:,.0f}",18,600),txt(220,33,135,f"{row['infeasible_draft_groups']} draft conflicts",10,400,'muted')],'Scenario pulse / '+key,'mint' if key==scenario else None,8,linkid))
 ch.append(pulse)
 brief=group(256,874,1152,153,[txt(24,22,970,'THE DECISION BRIEF · SELECTED BLOCK',10,600,'#9AC7C5'),txt(24,49,980,'Right worker. Right place. Right now.',26,600,'white'),txt(24,95,820,f"Warehouse 2 · Feb 14 · MID  |  {sum(a['employees'] for a in scene['plan']['allocations'])} assignments · ${scene['plan']['cost']:,.2f} projected block cost",13,400,'#D0E2E5'),btn(920,91,206,'Inspect this decision','secondary','optimizer','arrow')],'Selected-block decision brief','nav',12)
 ch.append(brief)
 comp=card(256,1051,1152,265,'Draft → recommended','SELECTED BLOCK · W2 / FEB 14 / MID')
 add(comp,badge(910,23,'Workforce verified',w=210),allocation_table(24,87,1104,scene));ch.append(comp)
 if scenario=='DISRUPT':ch.append(txt(256,1334,1140,'Operational review required: the Front End estimate reaches its 0.5% model floor. This does not validate real staffing cuts.',12,600,'amber'))
 return f

def demand_screen():
 f=shell('demand','Demand Intelligence','Anticipate the pressure. Inspect how the models earn your trust.',1540,active='demand');ch=f['children'];sv=S['service_metrics']['38']
 for j,args in enumerate([('Selected forecast','Same weekday 4','Past-only weekly-origin selection'),('Macro backtest WAPE','3.8%','9 warehouse / department series'),('Held-out Brier score',f"{sv['test']['brier']:.4f}",'Front End · lower is better')]):ch.append(metric(256+j*392,322,368,*args))
 demand=S['demand_charts']['38'];future=demand['future']
 chart=card(256,484,1152,361,'Front End · warehouse 2','PLANNING-WEEK DEMAND','Daily department-specific workload units · February 12–18')
 series=[{'values':[r['lower'] for r in future],'color':'#BCD5CC'},{'values':[r['upper'] for r in future],'color':'#BCD5CC'},{'values':[r['benchmark'] for r in future],'color':'#B4BEC5'},{'values':[r['forecast'] for r in future],'color':'primary'}]
 add(chart,pathplot(26,111,1085,178,series,['Feb '+r['day_date'][-2:].lstrip('0') for r in future]),txt(82,327,950,'TEAL  Selected forecast     GRAY  Supplied benchmark     PALE GREEN  Stress-envelope bounds',10,500,'muted'));ch.append(chart)
 methods=sorted(S['forecast_metrics']['wape'].items(),key=lambda x:x[1]);local={r['method']:r['wape'] for r in demand['local_forecast_evaluation']}
 back=card(256,869,662,379,'Simple models earn their place','TIME-AWARE BACKTEST','Two weekly-origin folds. No holdout updates inside each horizon.')
 rows=[[k.replace('_',' '),f'{v*100:.2f}%',f'{local[k]*100:.2f}%', 'Selected' if k=='same_weekday_4' else 'Compared'] for k,v in methods]
 add(back,table(24,104,614,['Method','Macro WAPE','W2 Front End','Decision'],rows,[218,115,135,146],44));ch.append(back)
 cal=card(942,869,466,379,'Front End · isotonic','SERVICE CALIBRATION','Held-out predictions versus observed target attainment')
 bins=sv['test']['calibration'];x0=44;y0=282;pw=370;ph=157
 for i in range(3):add(cal,line(x0,y0-ph*i/2,x0+pw,y0-ph*i/2),txt(9,y0-ph*i/2-7,30,f'{i*50}%',9,400,'muted'))
 add(cal,line(x0,y0,x0+pw,y0-ph,'#B6C8CE',1))
 points=[(x0+b['predicted']*pw,y0-b['observed']*ph) for b in bins]
 for a,b in zip(points,points[1:]):add(cal,line(*a,*b,'primary',2))
 for x,y in points:add(cal,rect(x-4,y-4,8,8,'primary',4))
 add(cal,txt(45,290,370,'Predicted target probability →',10,400,'muted'),txt(24,334,415,f"AUC  {sv['test']['auc']:.3f}       ECE  {sv['test']['ece']:.3f}       n = {sv['test']['n']}",12,600));ch.append(cal)
 ch.append(notice(256,1272,1152,'Evidence has boundaries','Six weeks of simulated history. Stress envelopes are not confidence intervals. The supplied future benchmark has no actual labels; no claim to beat it is made.',h=95))
 h=card(256,1391,1152,86)
 add(h,txt(24,20,840,'Inspect historical actuals in a separate source-backed view. Department workload units cannot be pooled.',12,400,'muted'),btn(926,19,202,'View actual history','secondary','demand-history','demand'));ch.append(h)
 return f

def optimizer_screen():
 scene=SCENES['BASE'];f=shell('optimizer','Staffing Optimizer','Put every qualified worker where they matter.',1350,active='optimizer');ch=f['children']
 priority=card(256,321,1152,108)
 add(priority,txt(24,17,260,'OPERATING PRIORITY',10,600,'muted'))
 for i,label in enumerate(['Service First','Balanced','Budget Conscious']):add(priority,btn(24+i*210,47,196,label,'primary' if i==0 else 'secondary',['optimizer','optimizer-balanced','optimizer-budget'][i]))
 add(priority,txt(726,45,402,'Service first, then minimum cost. Service breaks cost ties.',12,400,'muted'));ch.append(priority)
 for j,args in enumerate([('Front End staffing','31 → 35','Selected department · block assignments'),('Modeled target probability','99.5%','Front End · model estimate'),('Selected group labor cost','$6,614.46','All three departments · selected block')]):ch.append(metric(256+j*392,453,368,*args))
 c=card(256,615,1152,280,'One qualified workforce. No double counting.','JOINT INTEGER WORKFORCE')
 add(c,badge(939,24,'OPTIMAL · CP-SAT',w=188),allocation_table(24,95,1104,scene));ch.append(c)
 mix=card(256,919,580,278,'Where capacity comes from','ALLOCATION MIX')
 for i,a in enumerate(scene['plan']['allocations']):
  y=96+i*49;add(mix,txt(24,y,160,a['department'],12,500));xx=190
  for key,col in [('regular','primary'),('flex','#8CB1B2'),('overtime','#D6B56E')]:
   ww=a[key]/46*330
   if ww:add(mix,rect(xx,y+1,ww,19,col,3));xx+=ww
  add(mix,txt(530,y,35,str(a['employees']),12,600))
 add(mix,txt(24,248,530,'Regular  /  Borrowed flex  /  Overtime',10,500,'muted'));ch.append(mix)
 e=card(860,919,548,278,'Traceable, computed reasoning','EXPLAIN MY DECISION')
 add(e,txt(24,93,500,'Service First assigns 54 block employees at $6,614.46, a $120.31 increase over this block’s draft. The minimum-cost integer solution preserves maximum quantized modeled service.',13),txt(24,191,500,'Only unused qualified partner capacity can be borrowed. Pharmacy remains licensed-only.',12,400,'muted'),btn(24,229,220,'Inspect Last Worker','secondary','last-worker','arrow'));ch.append(e)
 ch.append(notice(256,1221,1152,'A schedule is not a service guarantee','All staffing results are aggregate pool allocations. They are not a named individual roster or causal permission to cut workers.',tone='good',h=84));return f

def lab_screen(id='scenario',pending=False):
 f=shell(id,'Scenario Lab','Change conditions. Recalculate. Understand what moved.',1330,active='scenario');ch=f['children']
 c=card(256,321,1152,381,'Prepare for what changes','SCENARIO INPUTS','Applies across all departments in the selected warehouse / date / shift.')
 add(c,txt(24,110,790,'Demand multiplier',13,600),txt(976,103,140,'120%' if pending else '100%',25,600,'primary'),rect(24,156,1094,6,'soft',3),rect(24,156,684 if pending else 410,6,'primary',3),rect((24+684 if pending else 24+410)-8,151,16,16,'primary',8),txt(24,176,150,'70%',10,400,'muted'),txt(1078,176,50,'150%',10,400,'muted'))
 add(c,txt(24,216,790,'Available workforce',13,600),txt(976,209,140,'85%' if pending else '100%',25,600,'primary'),rect(24,262,1094,6,'soft',3),rect(24,262,930 if pending else 1094,6,'primary',3),rect((954 if pending else 1118)-8,257,16,16,'primary',8),txt(24,282,150,'0%',10,400,'muted'),txt(1078,282,60,'100%',10,400,'muted'))
 add(c,group(22,104,1100,76,[],'Adjust demand / prototype example',link='scenario-pending'),group(22,210,1100,76,[],'Adjust availability / prototype example',link='scenario-pending'))
 add(c,txt(24,320,170,'Forecast sensitivity',11,500,'muted'),btn(194,311,238,'Central forecast  ›','secondary','scenario-pending'),btn(752,310,177,'Recalculate','primary','loading','pulse'),btn(945,310,182,'Restore official','secondary','scenario'))
 ch.append(c)
 ch.append(notice(256,726,1152,'Unsaved changes · ready to recalculate' if pending else 'Official assumptions are active','Pending controls do not change the displayed plan until a calculation succeeds.' if pending else 'Demand and availability use the original scenario inputs. Custom controls cannot create additional employees.',tone='warn' if pending else 'good',h=84))
 c=card(256,834,1152,281,'Protect service within real limits','LIVE SELECTED-BLOCK RESULT')
 add(c,badge(974,24,'FEASIBLE',w=150),allocation_table(24,94,1104,SCENES['BASE']));ch.append(c)
 recent=card(256,1139,1152,135,'Recent computed decisions','DECISION LOG')
 add(recent,txt(24,85,1080,'BASE · W2 · Feb 14 MID: $6,614.46 / 99.5% modeled service   ·   Official selection',12,500,'muted'));ch.append(recent)
 return f

def worker_card(x,y,w,scene,positive=False):
 c=card(x,y,w,393,'Assign eligible capacity to Merchandising' if positive else 'Keep the current allocation','THE LAST WORKER · MODEL ESTIMATES','The best one-worker decision accounts for the department giving up capacity.')
 if positive:
  rec=scene['last_worker']['recommendation'];main=group(24,110,(w-72)/2,177,[txt(18,17,(w-108)/2,'Recommended addition',11,600,'primary'),txt(18,47,(w-108)/2,'Unused qualified capacity → Merchandising',19,600),txt(18,122,(w-108)/2,f"+{rec['recipient_gain']*100:.2f} pp   /   $ {rec['incremental_cost']:,.2f}",22,600,'primary'),txt(18,153,(w-108)/2,'Recipient benefit  /  incremental block cost',10,400,'muted')],'Recommended eligible addition','mint',10)
  other=group(48+(w-72)/2,110,(w-72)/2,177,[txt(18,17,(w-108)/2,'Rejected borrowing alternative',11,600,'amber'),txt(18,47,(w-108)/2,'Front End → Merchandising',19,600),txt(18,103,(w-108)/2,'+5.14 pp  /  −41.17 pp',22,600,'amber'),txt(18,145,(w-108)/2,'Recipient gain  /  lender opportunity cost',10,400,'muted')],'Rejected qualified transfer','amberBg',10)
 else:
  main=group(24,110,(w-72)/2,177,[icon(18,19,'check',19,'primary'),txt(48,16,(w-172)/2,'No beneficial change',14,600,'primary'),txt(18,58,(w-110)/2,'No eligible one-worker change improves net modeled service at the solver precision. Retain this allocation.',14)],'No beneficial change','mint',10)
  other=group(48+(w-72)/2,110,(w-72)/2,177,[txt(18,17,(w-108)/2,'Test the borrowing alternative',11,600,'amber'),txt(18,47,(w-108)/2,'Merchandising → Front End',19,600),txt(18,103,(w-108)/2,'0.00 pp  /  −0.84 pp',22,600,'amber'),txt(18,145,(w-108)/2,'Recipient benefit  /  lender effect',10,400,'muted')],'Rejected transfer','amberBg',10)
 add(c,main,other)
 for i,label in enumerate(['Add to Merchandising','Add to Pharmacy','Front End → Merch.'] if positive else ['Add to Front End','Add to Merchandising','Add to Pharmacy']):add(c,btn(24+i*221,311,208,label,'secondary','last-worker' if positive else 'decision'))
 add(c,txt(24,365,w-48,'pp = percentage points. Marginal effects are model estimates, not causal guarantees.',11,400,'muted'));return c

def certificate(x,y,w,scene,h=318):
 c=card(x,y,w,h,'Feasibility Certificate','INDEPENDENT WORKFORCE CHECK','Verified pool conservation, qualifications, overtime and staffing minima.')
 add(c,badge(w-195,20,'FEASIBLE',w=171))
 for i,a in enumerate(scene['plan']['allocations']):
  yy=110+i*48
  add(c,txt(24,yy,180,a['department'],12,600),txt(205,yy,w-225,f"Local {a['regular']} · Lent {scene['plan']['allocations'][1-i]['flex'] if i<2 else 0} · Borrowed {a['flex']} · OT {a['overtime']}/{a['overtime_cap']}",11,400,'muted'),rect(24,yy+27,w-48,4,'soft',2),rect(24,yy+27,(w-48)*min(1,a['regular']/max(1,a['available_regular'])),4,'primary',2))
  lent=scene['plan']['allocations'][1-i]['flex'] if i<2 else 0
  if lent:add(c,rect(24+(w-48)*a['regular']/max(1,a['available_regular']),yy+27,(w-48)*lent/max(1,a['available_regular']),4,'gold',2))
 add(c,txt(24,270,w-48,'Front End ↔ Merchandising may share unused qualified regular capacity. Pharmacy uses its own qualified pool.',11,400,'muted'))
 return c

def frontier(x,y,w,scene,h=340):
 c=card(x,y,w,h,'Make the tradeoff explicit','COST–SERVICE FRONTIER','Selected block · nondominated among eight solved tolerances')
 prefix='frontier-last-' if scene['selection']['day_date']=='2026-02-13' else 'frontier-'
 points=scene['frontier'];costs=[p['cost'] for p in points];services=[p['service'] for p in points];maxc=max(costs);minc=min(costs);minp=max(0,min(services)-.035);maxp=min(1,max(services)+.015)
 x0=57;y0=238;pw=w-95;ph=121
 for i in range(3):add(c,line(x0,y0-i*ph/2,x0+pw,y0-i*ph/2),txt(10,y0-i*ph/2-6,48,f'{(minp+(maxp-minp)*i/2)*100:.0f}%',9,400,'muted'))
 coords=[(x0+(p['cost']-minc)/max(1,maxc-minc)*pw,y0-(p['service']-minp)/max(.001,maxp-minp)*ph) for p in points]
 for a,b in zip(coords,coords[1:]):add(c,line(*a,*b,'primary',2))
 for i,(xx,yy) in enumerate(coords):add(c,rect(xx-4,yy-4,8,8,'white',4,'primary'),group(xx-10,yy-10,20,20,[],'Select frontier alternative',link=f'{prefix}{i}'))
 add(c,txt(38,250,110,f'${minc:,.0f}',10,400,'muted'),txt(w-119,250,110,f'${maxc:,.0f}',10,400,'muted'))
 for i,p in enumerate(points[:4]):
  ww=(w-48)/min(4,len(points));xx=24+i*ww
  add(c,group(xx,281,ww-8,40,[txt(7,3,ww-22,f"${p['cost']:,.0f} / {p['service']*100:.1f}%",10,600,'primary')],'Frontier option','mint',6,f'{prefix}{i}'))
 return c

def export_card(x,y,w):
 c=card(x,y,w,258,'A plan you can put to work','OFFICIAL STAFFING EXPORT','Official Service First recommendations across BASE, PEAK and DISRUPT.')
 add(c,badge(24,105,'567 rows validated',w=190),txt(237,110,w-260,'Exact template · integer counts · closures · independent costs',11,400,'muted'))
 add(c,txt(24,156,108,'TEAM ID',10,600,'muted'),group(132,143,240,43,[txt(14,12,210,'SHIFTWISE',13,500)],'Team ID input','white',7,stroke='border'),btn(w-394,143,370,'Download staffing submission','primary','export-success','download'))
 add(c,txt(24,207,w-48,'Custom simulations and priority changes never overwrite this audited official CSV.',12,400,'muted'));return c

def decision_screen(id='decision',positive=False):
 scene=SCENES['LAST_WORKER'] if positive else SCENES['BASE'];h=1860
 f=shell(id,'Decision & Export','From insight to action. Inspect the feasible alternative before you commit.',h,active='decision',scenario='DISRUPT' if positive else 'BASE',context='Feb 13, 2026' if positive else 'Feb 14, 2026',shift='OPEN' if positive else 'MID',mode='Balanced' if positive else 'Service First')
 ch=f['children'];ch.append(worker_card(256,321,1152,scene,positive))
 ch += [certificate(256,738,552,scene),frontier(832,738,576,scene,340)]
 impact=card(256,1102,1152,223,'Recommended allocation · retained' if not positive else 'After the recommended eligible addition','DEPARTMENT IMPACT')
 for i,a in enumerate(scene['plan']['allocations']):
  xx=24+i*374;head=a['employees'];after=head+1 if positive and a['dept_id']==92 else head
  add(impact,txt(xx,88,330,a['department'],13,600),txt(xx,119,330,f'{head} → {after} block employees',22,600,'primary' if head!=after else 'ink'),txt(xx,160,330,'Eligible addition' if head!=after else 'Allocation retained',11,400,'muted'))
 ch.append(impact);ch.append(export_card(256,1349,1152))
 c=card(256,1631,1152,145,'Assumptions & evidence',sub='Simulated inputs. Six-week history. Model estimates. Aggregate qualified pools.')
 add(c,btn(24,87,244,'Read the evidence','secondary','evidence','help'),txt(307,96,800,'No individual employee roster or guaranteed wait-time outcome is implied.',12,400,'muted'));ch.append(c)
 return f

def evidence_screen():
 f=shell('evidence','Assumptions & evidence','The limits are part of the recommendation, not a footnote.',1330,active='decision');ch=f['children']
 sections=[('Dataset facts','Simulated competition data; warehouses 1, 2 and 4. History: Jan 1–Feb 11. Planning week: Feb 12–18, 2026. Three departments and three shifts.'),('Forecast evidence','Two past-only weekly-origin folds; 126 held-out daily records per method. Same weekday 4 selected at 3.7502% macro WAPE. Future benchmark performance is not observed.'),('Service model limits','Department-specific calibrated estimates. Associations are not causal effects. Stress envelopes are sensitivity ranges, not confidence intervals. Model plateaus can make marginal estimates unreliable.'),('Workforce and qualifications','Aggregate qualified pools, not a named-person roster. Front End and Merchandising conserve partner pools. Pharmacy is licensed-only. Receiving department rates and paid hours determine cost.'),('Optimization and frontier','Cost-minimizing CP-SAT within the chosen service-loss limit, then service tie-break. Frontier points are nondominated among eight solved tolerances, not an exhaustive continuous frontier.'),('Submission verification','567 original template rows; integer counts, closures, qualifications, pool conservation, overtime, minimums and costs independently checked. Custom simulations do not overwrite the official CSV.')]
 for i,(title,body) in enumerate(sections):
  c=card(256,321+i*145,1152,127,title)
  add(c,txt(24,61,1100,body,13,400,'muted'));ch.append(c)
 return f

def state_screen(id,title,kind):
 f=shell(id,title,'Clear system feedback. No stale recommendation disguised as a new result.',1180,active='scenario');ch=f['children']
 if kind=='loading':
  ch.append(notice(256,321,1152,'Solving qualified workforce allocations…','Inputs are locked while the engine audits and recalculates. A new recommendation will appear only after success.',tone='good'))
  for y in [439,600,761]:
   c=card(256,y,1152,134)
   add(c,rect(24,23,320,12,'soft',6),rect(24,55,900,22,'soft',5),rect(24,95,700,10,'soft',5));ch.append(c)
  ch.append(btn(256,931,200,'View resolved state','secondary','scenario'))
 elif kind=='error':
  ch.append(notice(256,321,1152,'The engine could not prove a recommendation in time','No new recommendation is shown. Retry or restore the official assumptions. The previous selected-block result is hidden.',h=104))
  ch += [btn(256,449,200,'Retry calculation','primary','loading'),btn(472,449,250,'Restore assumptions','secondary','scenario')]
  c=card(256,521,1152,280,'Official week reference · no new recommendation','REFERENCE ONLY','These official BASE totals are not a result for the failed custom request.')
  add(c,statbox(24,113,350,'Projected weekly cost','$326,103','Official BASE · all warehouses'),statbox(398,113,350,'Modeled service','99.2%','Official BASE · all open blocks'),txt(784,129,332,'Recalculate successfully before using a custom recommendation.',16,600,'amber'));ch.append(c)
 elif kind=='conflict':
  ch.append(notice(256,321,1152,'MINIMUM_CONFLICT · no executable simulation','Available qualified capacity cannot satisfy a source staffing minimum. Do not present this state as a validated staffing plan.',h=104))
  c=card(256,449,1152,273,'Staffing minimum conflict','STATE TEMPLATE · NO CUSTOM VALUES FABRICATED')
  add(c,table(24,99,1104,['Department','Recommended','Minimum','Resolution'],[['Affected department','—','Source-defined','Review qualified capacity'],['Other departments','—','Source-defined','Recalculate after intervention']],[300,200,190,414]),txt(24,237,1050,'This is a UI-state specification. The numerical conflict details must be populated by a real failed calculation.',11,400,'muted'));ch.append(c)
  ch += [btn(256,746,250,'Restore assumptions','primary','scenario'),btn(523,746,220,'Review certificate','secondary','decision')]
 elif kind=='closed':
  ch.append(notice(256,321,1152,'Closed block · zero staffing','BASE · Warehouse 1 · Feb 14, 2026 · EVE · Pharmacy. This source block is closed; model probability is not applicable.',tone='good',h=104))
  for j,args in enumerate([('Block assignments','0 → 0','Draft and recommended'),('Projected department cost','$0.00','Regular 0 · flex 0 · overtime 0'),('Modeled service','Closed','No probability is shown for a closed block')]):ch.append(metric(256+j*392,449,368,*args))
  ch.append(btn(256,623,252,'Return to selected block','secondary','optimizer'))
 elif kind=='export':
  ch.append(notice(256,321,1152,'Official submission is ready','567 rows validated. The download action in the live app retrieves the official staffing CSV. This Figma prototype is a visual flow, not a live file export.',tone='good',h=104))
  ch.append(export_card(256,449,1152));ch.append(btn(256,731,220,'Back to decisions','secondary','decision'))
 return f

def balanced_screen():
 f=optimizer_screen();f['id']='optimizer-balanced';f['name']='Staffing Optimizer / Balanced comparison'
 # Same selected block; use the exact saved frontier alternative closest to 2% loss.
 base=SCENES['BASE'];p=next(z for z in base['frontier'] if abs(z['cost']-6429.15)<.01)
 # Replace the corresponding visual fields, leaving no unrelated business value changed.
 def visit(nodes):
  for n in nodes:
   if n['type']=='text':
    old=n['text']
    if old=='$6,614.46':n['text']='$6,429.15'
    if old=='31 → 35':n['text']='31 → '+str(p['allocations'][0]['employees'])
    if old.startswith('Service First assigns 54'):
     repl=txt(n['x'],n['y'],n['width'],'Balanced permits up to 2 percentage points of mean modeled service loss. It minimizes cost within that limit and uses service to break cost ties.',13);n.update(repl)
   if n.get('name')=='Button / Service First':n['fill']=C['white'];n['children'][-1]['fill']=C['ink']
   if n.get('name')=='Button / Balanced':n['fill']=C['primary'];n['children'][-1]['fill']=C['white']
   if 'children'in n:visit(n['children'])
 visit(f['children'])
 # Replace allocation table, mix and service metric using this exact frontier plan.
 import copy
 sc=copy.deepcopy(base);sc['plan']=p
 for i,n in enumerate(f['children']):
  if n.get('name')=='One qualified workforce. No double counting.':
   n['children']=[c for c in n['children'] if c.get('name')!='Data table'];n['children'].append(allocation_table(24,95,1104,sc))
  if n.get('name')=='Metric / Modeled target probability':
   n['children'][1]['text']=f"{p['allocations'][0]['probability']*100:.1f}%"
  if n.get('name')=='Where capacity comes from':
   n['children']=[c for c in n['children'] if c.get('y',0)<80]
   for j,a in enumerate(p['allocations']):
    yy=96+j*49;add(n,txt(24,yy,160,a['department'],12,500));xx=190
    for key,col in [('regular','primary'),('flex','#8CB1B2'),('overtime','#D6B56E')]:
     ww=a[key]/46*330
     if ww:add(n,rect(xx,yy+1,ww,19,col,3));xx+=ww
    add(n,txt(530,yy,35,str(a['employees']),12,600))
   add(n,txt(24,248,530,'Regular  /  Borrowed flex  /  Overtime',10,500,'muted'))
 return f

def guide_screen(key,i):
 positive=key=='LAST_WORKER';sc=SCENES[key if i<4 else 'LAST_WORKER'];titles=['Start with the expected week.','Demand rises. The plan responds.','A feasible plan can still carry risk.','Who gets the last worker?','Make the tradeoff explicit.'];ids=['guide-base','guide-peak','guide-disrupt','guide-worker','guide-export'];h=1270
 f={'id':ids[i],'name':f'Guided demo / {i+1:02} / '+titles[i],'width':1440,'height':h,'children':[rect(0,0,1440,h,'paper')]};ch=f['children']
 ch += [rect(0,0,1440,72,'white'),icon(32,23,'pulse',25,'primary'),txt(74,24,600,'SHIFTWISE / Live decision briefing',20,600),btn(1081,18,150,'Exit presentation','secondary','command'),btn(1245,18,163,'Next scene','primary',ids[min(4,i+1)],'arrow')]
 prog=group(32,96,1376,100,[],'Guided progress','nav',12)
 for j,lab in enumerate(['BASE','PEAK','DISRUPT','LAST WORKER','DECIDE & EXPORT']):
  x=24+j*269;add(prog,group(x,20,254,35,[rect(0,1,28,28,'#247F75' if j==i else 'navHi',14),txt(9,5,20,str(j+1),11,600,'white'),txt(40,5,207,lab,11,600,'white' if j==i else '#9DB9C1')],'Guide / '+lab,link=ids[j]))
 add(prog,txt(24,70,1000,f'Scene {i+1} / 5  ·  Real model decisions, shown as an editable design snapshot',11,400,'#B2CBD1'),group(1210,64,125,30,[txt(10,4,100,'Reset to BASE',11,500,'white')],'Reset guide',link='guide-base'));ch.append(prog)
 ch += [txt(32,229,1000,'FORGE / '+['FORECAST','OPTIMIZE','GUARD','REALLOCATE','EVALUATE'][i],11,600,'primary'),txt(32,259,1100,titles[i],36,700),txt(32,321,1200,f"Warehouse 2 · {sc['selection']['day_date']} · {sc['selection']['shift_code']} · {sc['selection']['mode']} · {['BASE','PEAK','DISRUPT','DISRUPT','DISRUPT'][i]}",14,400,'muted')]
 if i<3:
  for j,(lab,val,note) in enumerate([('Projected block labor cost',f"${sc['plan']['cost']:,.2f}",'All three departments'),('Modeled target attainment',f"{sc['plan']['service']*100:.1f}%",'Mean across open departments'),('Independent workforce check','Feasible','Aggregate pool constraints pass')]):ch.append(statbox(32+j*466,372,444,lab,val,note))
  c=card(32,526,1376,318,'From the draft to the selected recommendation','STAFFING BY DEPARTMENT');add(c,allocation_table(24,97,1328,sc));ch.append(c)
  text='The minimum-cost allocation retains maximum quantized modeled service.' if i<2 else 'Front End reaches the model’s 0.5% floor. This is a model limitation, not evidence that operational cuts are safe.'
  ch.append(notice(32,868,1376,'Demand and capacity tell different stories' if i==2 else 'Explain the recommendation',text,tone='warn' if i==2 else 'good',h=109))
  ch.append(btn(32,1001,260,'Inspect full workspace','secondary','decision','arrow'))
 elif i==3:
  ch.append(worker_card(32,372,1376,sc,True));ch.append(notice(32,789,1376,'An unused qualified worker is not a free transfer','The recipient gains 5.14 percentage points, with no lender loss, at $187.20 extra block cost. Taking a worker from Front End instead destroys more modeled service than it creates.',tone='good',h=114));ch.append(btn(32,927,260,'Inspect all alternatives','secondary','last-worker','arrow'))
 else:
  ch += [certificate(32,372,660,sc),frontier(716,372,692,sc),export_card(32,738,1376)]
  ch.append(notice(32,1020,1376,'What this model cannot promise','Simulated data, aggregate qualified pools, estimated service outcomes. Inspect every constraint and keep operational review in the decision.',h=93))
 ch.append(txt(32,1218,1300,'SIMULATED COMPETITION DATA  /  Projected costs and modeled service estimates, not observed business outcomes.',11,400,'muted'))
 return f

def login_screen():
 f={'id':'login','name':'Protected demo / Sign in','width':1440,'height':980,'children':[rect(0,0,1440,980,'paper'),rect(0,0,620,980,'nav')]};ch=f['children']
 ch += [icon(56,61,'pulse',34,'#7AD8C2'),txt(106,61,460,'SHIFTWISE',25,700,'white'),txt(56,259,506,'Every workforce decision, explained.',48,700,'white'),txt(56,474,490,'A competition demonstration grounded in qualified capacity, projected cost and modeled service.',19,400,'#B2CBD1'),txt(56,839,480,'FORGE  /  FORECAST · OPTIMIZE · REALLOCATE · GUARD · EVALUATE',10,600,'#8FB2BC')]
 c=card(770,240,524,441,'Competition demo access','PROTECTED DEMONSTRATION','Enter the shared demo password supplied by your team.')
 add(c,txt(24,124,470,'Password',12,600),group(24,154,476,48,[txt(16,12,438,'Enter demo password',14,400,'muted')],'Password input','white',8,stroke='border'),btn(24,226,476,'Open the demo','primary','command','lock',48),txt(24,304,476,'The hosted demo uses signed sessions. Do not share credentials publicly or include them in slides.',12,400,'muted'),txt(24,385,476,'Shared competition access · not individual enterprise accounts',10,400,'muted'));ch.append(c)
 return f

def mobile_screen(id='mobile-command',kind='command'):
 heights={'command':1800,'scenario':1550,'decision':1920};h=heights[kind];f={'id':id,'name':'Mobile / '+{'command':'Command Center','scenario':'Scenario Lab','decision':'Decision & Export'}[kind],'width':390,'height':h,'children':[rect(0,0,390,h,'paper'),rect(0,0,56,h,'nav')]};ch=f['children'];x=72;w=302
 ch += [icon(17,21,'pulse',24,'#88D1BF'),txt(x,23,w,'SHIFTWISE / Workforce planning',11,600),txt(x,63,w,{'command':'Command Center','scenario':'Scenario Lab','decision':'Decision & Export'}[kind],24,700)]
 for i,(k,label) in enumerate(NAV):ch.append(group(5,83+i*54,46,42,[icon(13,11,k,21,'#B9DDD8')],'Mobile nav / '+label,'navHi' if k==kind else None,8,{'command':'mobile-command','scenario':'mobile-scenario','decision':'mobile-decision'}.get(k,'mobile-command')))
 ch.append(btn(x,111,w,'Start guided demo','secondary','mobile-guide','play'))
 fields=[('Warehouse','02 · Large'),('Date','Feb 14, 2026'),('Shift','MID'),('Department','Front End')]
 for i,(lab,val) in enumerate(fields):
  xx=x+(i%2)*158;yy=171+(i//2)*67
  ch.append(group(xx,yy,144,58,[txt(12,8,122,lab,9,500,'muted'),txt(12,29,122,val,11,600)],'Mobile selector / '+lab,'white',8,stroke='border'))
 for i,key in enumerate(['BASE','PEAK','DISRUPT']):ch.append(group(x+i*102,316,98,36,[txt(12,10,80,key,10,600,'primary' if i==0 else 'muted')],'Scenario / '+key,'mint' if i==0 else 'white',7))
 if kind=='command':
  ch.append(txt(x,379,w,'OFFICIAL WEEK · ALL WAREHOUSES',9,600,'muted'))
  for i,args in enumerate([('Projected labor cost','$326,103','Official BASE · simulated case data'),('Modeled service attainment','99.2%','Open blocks · model estimates'),('Blocks below 95% estimate','1','Remaining service risk'),('Infeasible draft groups','0','Source draft pool checks')]):ch.append(metric(x,408+i*154,w,*args))
  c=card(x,1048,w,283,'Selected block','W2 / FEB 14 / MID')
  add(c,table(16,94,w-32,['Department','Draft','Plan'],[['Front End',31,35],['Merchandising',17,17],['Pharmacy',3,2]],[142,62,66],43));ch.append(c)
  ch.append(notice(x,1355,w,'Workforce verified','Selected block cost: $6,614.46. This is separate from weekly totals.',tone='good',h=128))
  ch.append(btn(x,1507,w,'Inspect the allocation','primary','mobile-decision','arrow'))
  ch.append(btn(x,1571,w,'Open Scenario Lab','secondary','mobile-scenario','scenario'))
 elif kind=='scenario':
  c=card(x,379,w,410,'Change conditions','SCENARIO INPUTS')
  for i,(lab,val) in enumerate([('Demand multiplier','100%'),('Available workforce','100%')]):
   yy=105+i*95;add(c,txt(18,yy,208,lab,12,500),txt(218,yy,68,val,15,600,'primary'),rect(18,yy+43,266,5,'soft',3),rect(18,yy+43,266,5,'primary',3),rect(276,yy+38,14,14,'primary',7))
  add(c,txt(18,297,266,'Forecast sensitivity',10,500,'muted'),btn(18,320,266,'Central forecast  ›','secondary'));ch.append(c)
  ch += [btn(x,813,w,'Recalculate','primary','mobile-decision','pulse',44),btn(x,873,w,'Restore official assumptions','secondary','mobile-scenario')]
  ch.append(notice(x,937,w,'Official assumptions active','The selected block is feasible. Source availability is the ceiling.',tone='good',h=129))
  c=card(x,1090,w,248,'Live result','SELECTED BLOCK')
  add(c,txt(20,93,w-40,'$6,614.46',32,600),txt(20,146,w-40,'99.5% modeled service',17,600,'primary'),txt(20,187,w-40,'All three departments · official BASE',11,400,'muted'));ch.append(c)
 else:
  c=card(x,379,w,348,'Keep the allocation','THE LAST WORKER')
  add(c,badge(18,94,'No beneficial change',w=264),txt(18,147,w-36,'An eligible move must improve service after the lender’s opportunity cost.',15),txt(18,233,w-36,'Merchandising → Front End',12,600),txt(18,262,w-36,'0.00 pp gain / −0.84 pp lender effect',13,600,'amber'));ch.append(c)
  ch.append(certificate(x,751,w,SCENES['BASE'],390))
  # Use a separately designed narrow certificate rather than clipped desktop rows.
  c=ch[-1];c['children']=[z for z in c['children'] if z.get('y',0)<85 and not z.get('name','').startswith('Badge /')]
  for z in c['children']:
   if z.get('name','').startswith('Verified pool conservation'):z.update(txt(18,77,w-36,'Qualified pools + overtime checks',11,400,'muted'))
  for i,a in enumerate(SCENES['BASE']['plan']['allocations']):
   yy=113+i*70;add(c,txt(18,yy,w-36,a['department'],12,600),txt(18,yy+25,w-36,f"Local {a['regular']} · Lent {SCENES['BASE']['plan']['allocations'][1-i]['flex'] if i<2 else 0} · Flex {a['flex']} · OT {a['overtime']}/{a['overtime_cap']}",11,400,'muted'),rect(18,yy+50,(w-36)*a['regular']/max(1,a['available_regular']),4,'primary',2))
   lent=SCENES['BASE']['plan']['allocations'][1-i]['flex'] if i<2 else 0
   if lent:add(c,rect(18+(w-36)*a['regular']/max(1,a['available_regular']),yy+50,(w-36)*lent/max(1,a['available_regular']),4,'gold',2))
  add(c,txt(18,335,w-36,'Pharmacy uses its own qualified pool.',11,400,'muted'))
  ch.append(frontier(x,1165,w,SCENES['BASE'],395))
  c=ch[-1];c['children']=[z for z in c['children'] if z.get('y',0)<280]
  for z in c['children']:
   if z.get('name')=='Make the tradeoff explicit':z.update(txt(24,40,w-48,'Cost vs. service',19,600))
  for i,p in enumerate(SCENES['BASE']['frontier']):add(c,txt(20+(i%2)*145,295+(i//2)*37,137,f"${p['cost']:,.0f} / {p['service']*100:.1f}%",10,600,'primary'))
  ch.append(btn(x,1584,w,'Download official CSV','primary','mobile-decision','download',46))
  ch.append(notice(x,1654,w,'567 rows validated','Custom simulations never overwrite the audited official export.',tone='good',h=122))
 ch.append(txt(x,h-65,w,'SIMULATED DATA · MODELED ESTIMATES',9,600,'muted'))
 return f

def tablet_screen():
 f={'id':'tablet-command','name':'Tablet / Command Center','width':1024,'height':1440,'children':[rect(0,0,1024,1440,'paper'),rect(0,0,64,1440,'nav'),rect(64,0,960,64,'white')]};ch=f['children'];ch += [icon(20,22,'pulse',25,'#89D5C3'),txt(88,21,700,'SHIFTWISE / Workforce planning',15,600)]
 for i,(k,label) in enumerate(NAV):ch.append(group(8,91+i*57,48,44,[icon(13,12,k,22,'#ACD2D0')],'Tablet / '+label,'navHi' if i==0 else None,7))
 ch += [txt(88,99,800,'Command Center',30,700),txt(88,148,800,'Your week, in perspective. Official BASE · all warehouses.',13,400,'muted'),btn(776,101,224,'Start guided demo','secondary',ic='play')]
 for j,(lab,val) in enumerate([('Warehouse','02 · Large'),('Date','Feb 14, 2026'),('Shift','MID'),('Scenario','BASE')]):ch.append(group(88+j*232,194,216,73,[txt(16,12,184,lab,10,500,'muted'),txt(16,36,184,val,13,600)],'Context / '+lab,'white',10,stroke='border'))
 for i,args in enumerate([('Projected labor cost','$326,103','Official weekly projection'),('Modeled service attainment','99.2%','Mean across open blocks'),('Blocks below 95% estimate','1','Remaining modeled risk'),('Infeasible draft groups','0','Source draft workforce conflicts')]):ch.append(metric(88+(i%2)*468,291+(i//2)*160,444,*args))
 c=card(88,635,912,343,'Pressure changes the plan','SCENARIO PULSE','Official weekly projections, not selected block results')
 add(c,table(24,108,864,['Scenario','Projected cost','Modeled service','Draft conflicts'],[[r['scenario_code'],f"${r['cost']:,.0f}",f"{r['modeled_service']*100:.1f}%",r['infeasible_draft_groups']] for r in S['weekly_scenarios']],[245,230,220,169],60));ch.append(c)
 c=card(88,1002,912,315,'Draft → recommended','SELECTED BLOCK · W2 / FEB 14 / MID')
 add(c,table(24,104,864,['Department','Draft','Recommended','Projected cost'],[[a['department'],a['draft_employees'],a['employees'],f"${a['cost']:,.2f}"] for a in SCENES['BASE']['plan']['allocations']],[280,140,190,254]));ch.append(c)
 ch.append(txt(88,1365,900,'SIMULATED CASE DATA · Projected cost and modeled service, not guaranteed outcomes.',11,400,'muted'));return f

def foundations():
 f={'id':'foundations','name':'Design system / Foundations','width':1440,'height':1390,'children':[rect(0,0,1440,1390,'paper')]};ch=f['children'];ch += [txt(40,38,1330,'SHIFTWISE / Design foundations',36,700),txt(40,96,1300,'A calm enterprise workspace: precise numbers, clear decisions, visible limits.',16,400,'muted'),txt(40,156,1300,'01 / SEMANTIC COLOR',11,600,'primary')]
 for i,(name,color) in enumerate(C.items()):
  xx=40+(i%7)*198;yy=197+(i//7)*133
  ch += [rect(xx,yy,180,66,color,10,'border'),txt(xx,yy+76,185,name,13,600),txt(xx,yy+98,185,color,11,400,'muted')]
 ch += [txt(40,627,640,'02 / TYPE & NUMBER HIERARCHY',11,600,'primary')]
 for i,(lab,size,weight) in enumerate([('Display · 40 / Semibold',40,600),('Heading 1 · 32 / Bold',32,700),('Section heading · 19 / Semibold',19,600),('Body · 14 / Regular',14,400),('Label · 12 / Medium',12,500),('Caption · 10 / Regular',10,400)]):ch.append(txt(40,670+i*72,720,lab,size,weight))
 ch += [txt(825,627,550,'03 / SPACE & STRUCTURE',11,600,'primary')]
 for i,v in enumerate([4,8,12,16,24,32,48,64]):ch += [txt(825,674+i*45,70,str(v)+' px',12,500,'muted'),rect(906,677+i*45,v*4,14,'primary',3)]
 ch += [txt(40,1151,1310,'04 / ACCESSIBILITY & HONEST STATUS',11,600,'primary'),txt(40,1192,1310,'Use text + icon with every status. Show units and scope next to values. Retain keyboard focus, readable contrast, explicit loading, and errors that hide stale recommendations.',16),txt(40,1284,1310,'Inter is the intended Figma typeface. Fixed artboards document layouts; the working application remains the source of live calculations.',12,400,'muted')];return f

def interaction_notes():
 f={'id':'interaction-notes','name':'Design system / Interaction and provenance','width':1440,'height':1530,'children':[rect(0,0,1440,1530,'paper')]};ch=f['children'];ch += [txt(40,38,1330,'From screen to decision',36,700),txt(40,97,1300,'Prototype map, state rules and source provenance',16,400,'muted')]
 rows=[('Command Center','Demand Intelligence','Inspect demand evidence'),('Command Center','Staffing Optimizer','Inspect this decision'),('Scenario Lab','Loading → result / error','Recalculate using the application'),('Decision & Export','Last Worker / frontier','Inspect opportunity cost and feasibility'),('Guided demo','BASE → PEAK → DISRUPT → Last Worker → Export','Next, reset and exit'),('Protected access','Sign in → workspace → Lock demo','Shared demo gate; not individual enterprise identity')]
 ch.append(table(40,164,1360,['Starting point','Destination / flow','Intent'],rows,[310,590,460],67))
 blocks=[('Prototype boundaries','Prepared frames represent verified snapshots and interface states. Figma navigation does not execute forecasting, optimization, authentication, file downloads or live sliders.'),('Calculation errors','Hide the stale selected-block recommendation. Keep only a clearly labeled official-week reference. Show retry and restore actions.'),('Source provenance','Charts and figures come from the saved audited CSV/JSON artifacts in vinetum/casecomp. All data are simulated. No new model results were invented for this design.'),('Data scopes','Week cards: official scenario across all warehouses. Context selectors: warehouse/date/shift. Block tables: all three departments. Department service metrics: selected department only.'),('Small screens','Narrow navigation rail, stacked cards, two-column selectors, readable scrollable tables. Responsive artboards are design specifications, not a claim that the plugin generates production React.'),('Account status','This package has not been executed in a connected Figma account. Run the included local plugin once to create native layers, then save/share the actual Figma file.')]
 for i,(title,body) in enumerate(blocks):
  c=card(40,663+i*130,1360,110,title);add(c,txt(24,57,1310,body,13,400,'muted'));ch.append(c)
 return f


def svg_nodes(nodes):
 out=[]
 for n in nodes:
  typ=n['type'];x=n.get('x',0);y=n.get('y',0);name=html.escape(n.get('name',''),quote=True)
  if typ=='rect':out.append(f'<rect data-name="{name}" x="{x}" y="{y}" width="{n["width"]}" height="{n["height"]}" rx="{n.get("radius",0)}" fill="{n.get("fill","none")}" stroke="{n.get("stroke","none")}"/>')
  elif typ=='text':
   out.append(f'<text data-name="{name}" x="{x}" y="{y+n["fontSize"]}" font-family="Inter,Arial,sans-serif" font-size="{n["fontSize"]}" font-weight="{n.get("fontWeight",400)}" fill="{n["fill"]}">')
   for j,l in enumerate(n['text'].split('\n')):out.append(f'<tspan x="{x}" dy="{0 if j==0 else n.get("lineHeight",n["fontSize"]*1.45)}">{html.escape(l)}</tspan>')
   out.append('</text>')
  elif typ=='line':out.append(f'<line x1="{x}" y1="{y}" x2="{n["x2"]}" y2="{n["y2"]}" stroke="{n["stroke"]}" stroke-width="{n.get("strokeWidth",1)}"/>')
  elif typ=='svg':out.append(f'<svg x="{x}" y="{y}" width="{n["width"]}" height="{n["height"]}" viewBox="0 0 24 24">'+re.sub(r'^<svg[^>]*>|</svg>$','',n['svg']).replace('<path','<path fill="none" stroke="'+re.search(r'stroke="([^"]+)"',n['svg']).group(1)+'" stroke-width="1.7"').replace('<rect','<rect fill="none" stroke="'+re.search(r'stroke="([^"]+)"',n['svg']).group(1)+'" stroke-width="1.7"').replace('<circle','<circle fill="none" stroke="'+re.search(r'stroke="([^"]+)"',n['svg']).group(1)+'" stroke-width="1.7"')+'</svg>')
  else:
   inside=[]
   if n.get('fill') or n.get('stroke'):inside.append(f'<rect width="{n["width"]}" height="{n["height"]}" rx="{n.get("radius",0)}" fill="{n.get("fill","none")}" stroke="{n.get("stroke","none")}"/>')
   inside.append(svg_nodes(n.get('children',[])))
   g=f'<g data-name="{name}" transform="translate({x},{y})">'+''.join(inside)+'</g>'
   if n.get('link'):g=f'<a href="#{n["link"]}" data-frame-link="{n["link"]}">{g}</a>'
   out.append(g)
 return ''.join(out)
def svg_frame(f):return f'<svg xmlns="http://www.w3.org/2000/svg" width="{f["width"]}" height="{f["height"]}" viewBox="0 0 {f["width"]} {f["height"]}"><title>{html.escape(f["name"])}</title>'+svg_nodes(f['children'])+'</svg>'

def history_screen():
 f=shell('demand-history','Historical demand evidence','Inspect actual simulated inputs separately from future forecasts.',1100,active='demand');ch=f['children']
 actual=[r for r in S['demand_charts']['38']['history'] if r['day_date']>='2026-01-22']
 c=card(256,321,1152,468,'Front End · Warehouse 2','HISTORICAL ACTUALS','January 22–February 11 · source workload units, not aggregated across departments')
 values=[r['daily_demand_units'] for r in actual];labels=[r['day_date'][5:] if i%3==0 else '' for i,r in enumerate(actual)]
 add(c,pathplot(30,125,1082,232,[{'values':values,'color':'primary'}],labels),txt(80,418,1000,'Observed simulated workload. The future planning-week chart is a separate modeled projection.',12,400,'muted'));ch.append(c)
 ch.append(notice(256,813,1152,'A short history has limits','Six weeks do not establish reliable holiday-specific causal effects. The central forecast does not invent a holiday uplift.',h=95))
 ch.append(btn(256,932,260,'Back to forecast evidence','secondary','demand','arrow'));return f

def budget_screen():
 f=balanced_screen();f['id']='optimizer-budget';f['name']='Staffing Optimizer / Budget Conscious comparison'
 def update(ns):
  for n in ns:
   if n.get('name')=='Button / Balanced':n['fill']=C['white'];n['children'][-1]['fill']=C['ink']
   if n.get('name')=='Button / Budget Conscious':n['fill']=C['primary'];n['children'][-1]['fill']=C['white']
   if n['type']=='text' and n.get('text','').startswith('Balanced permits'):
    n.update(txt(n['x'],n['y'],n['width'],'Budget Conscious permits up to 6 percentage points of mean modeled service loss. For this source block, its minimum-cost allocation coincides with Balanced.',13))
   update(n.get('children',[]))
 update(f['children']);return f

def frontier_screen(index,last=False):
 import copy
 sc=copy.deepcopy(SCENES['LAST_WORKER' if last else 'BASE']);p=sc['frontier'][index];sc['plan']=p
 id=f'frontier-{"last-" if last else ""}{index}'
 f=shell(id,'Frontier alternative','Inspect the source-backed allocation behind the selected cost–service point.',1220,active='decision',scenario='DISRUPT' if last else 'BASE',context='Feb 13, 2026' if last else 'Feb 14, 2026',shift='OPEN' if last else 'MID',mode='Frontier alternative');ch=f['children']
 for j,args in enumerate([('Projected block cost',f"${p['cost']:,.2f}",'All departments · selected block'),('Mean modeled service',f"{p['service']*100:.2f}%",'Mean across open departments'),('Assigned block employees',str(sum(a['employees'] for a in p['allocations'])),'Aggregate staffing, not unique weekly people')]):ch.append(metric(256+j*392,321,368,*args))
 c=card(256,483,1152,285,'The allocation behind this point','SOURCE-VERIFIED FRONTIER ALTERNATIVE')
 add(c,allocation_table(24,99,1104,sc));ch.append(c)
 ch.append(notice(256,792,1152,'Feasible does not mean risk-free','Each point is nondominated among eight solved tolerances. Read the department probabilities and remaining risk, not only the aggregate mean.',h=98))
 ch += [btn(256,914,250,'Back to frontier','primary','last-worker' if last else 'decision','arrow'),btn(526,914,240,'Inspect capacity rules','secondary','evidence','help')]
 return f

def mobile_guide():
 f={'id':'mobile-guide','name':'Mobile / Guided BASE scene','width':390,'height':1640,'children':[rect(0,0,390,1640,'paper'),rect(0,0,56,1640,'nav')]};ch=f['children'];x=72;w=302
 ch += [icon(17,21,'pulse',24,'#88D1BF'),txt(x,23,w,'SHIFTWISE / Live briefing',12,600),txt(x,75,w,'Start with the expected week.',27,700)]
 c=group(x,173,w,120,[],'Guided progress','nav',10)
 for i,lab in enumerate(['BASE','PEAK','DISRUPT','WORKER','EXPORT']):add(c,rect(15+i*55,20,24,24,'primary' if i==0 else 'navHi',12),txt(23+i*55,23,20,str(i+1),10,600,'white'),txt(10+i*55,56,57,lab,7,600,'#B2CBD1'))
 add(c,txt(16,91,w-32,'Scene 1 / 5 · guided design snapshot',10,400,'#B2CBD1'));ch.append(c)
 ch.append(txt(x,317,w,'Warehouse 2 · Feb 14 · MID · BASE',12,500,'muted'))
 for i,args in enumerate([('Projected block labor cost','$6,614.46','All three departments'),('Modeled target attainment','99.5%','Mean across open departments'),('Workforce check','Feasible','Independent qualified-pool check')]):ch.append(metric(x,360+i*155,w,*args))
 c=card(x,849,w,290,'Draft → recommendation','DEPARTMENT STAFFING')
 add(c,table(16,99,w-32,['Department','Draft','Plan'],[['Front End',31,35],['Merchandising',17,17],['Pharmacy',3,2]],[142,62,66],44));ch.append(c)
 ch += [btn(x,1163,w,'Inspect decision & export','primary','mobile-decision','arrow'),btn(x,1227,w,'Reset this scene','secondary','mobile-guide'),btn(x,1291,w,'Exit presentation','secondary','mobile-command')]
 ch.append(notice(x,1355,w,'Modeled estimates','A feasible staffing plan does not guarantee service outcomes.',tone='good',h=132));return f

def export_error_screen():
 f=state_screen('export-error','Export unavailable','export');ch=f['children']
 # Clear misleading success panels while retaining the real shell and context.
 ch[:]=[n for n in ch if n.get('y',0)<300 or n.get('y',0)>1100]
 ch.append(notice(256,321,1152,'The staffing file could not be downloaded','No new file is confirmed. Retry the export or return to the official plan. Do not substitute an unvalidated simulation.',h=106))
 ch += [btn(256,451,250,'Retry official export','primary','export-success','download'),btn(527,451,220,'Back to decisions','secondary','decision')]
 return f


def main():
 global S,SCENES
 S=json.loads((P/'source_data.json').read_text());SCENES={r['id']:r for r in S['scenes']}
 desk=[command_screen(),demand_screen(),optimizer_screen(),lab_screen(),decision_screen(),decision_screen('last-worker',True),command_screen('command-peak','PEAK'),command_screen('command-disrupt','DISRUPT'),balanced_screen(),lab_screen('scenario-pending',True),evidence_screen(),state_screen('loading','Calculating your staffing plan','loading'),state_screen('error','Calculation needs attention','error'),state_screen('minimum-conflict','Minimum staffing conflict','conflict'),state_screen('closed','Closed block','closed'),state_screen('export-success','Official submission ready','export'),login_screen()]
 for i,key in enumerate(['BASE','PEAK','DISRUPT','LAST_WORKER','LAST_WORKER']):desk.append(guide_screen(key,i))
 desk += [history_screen(),budget_screen(),export_error_screen()]
 desk += [frontier_screen(i) for i in range(len(SCENES['BASE']['frontier']))]
 desk += [frontier_screen(i,True) for i in range(len(SCENES['LAST_WORKER']['frontier']))]
 # The closed block must expose the same context in controls and body.
 closed=next(f for f in desk if f['id']=='closed')
 context=next(n for n in closed['children'] if n.get('name')=='Context selectors')
 for n in context['children']:
  if n.get('type')=='text' and n.get('text') in ['02 · Large','MID','Front End']:
   n['text']={'02 · Large':'01 · Medium','MID':'EVE','Front End':'Pharmacy'}[n['text']]
 D['pages']=[{'name':'01 · Desktop workspace','frames':desk},{'name':'02 · Responsive','frames':[tablet_screen(),mobile_screen(),mobile_screen('mobile-scenario','scenario'),mobile_screen('mobile-decision','decision'),mobile_guide()]},{'name':'03 · Foundations & components','frames':[foundations(),interaction_notes()]}]
 # Use native reusable instances for simple buttons; preserve richer icon controls exactly.
 def native_buttons(nodes):
  for n in nodes:
   if n.get('componentKey') and not any(c['type']=='svg' for c in n.get('children',[])):n['componentKey']='button.primary' if n.get('fill')==C['primary'] else 'button.secondary'
   native_buttons(n.get('children',[]))
 for p in D['pages']:
  for f in p['frames']:
   native_buttons(f['children'])
   if f['id'].startswith('mobile'):
    def sanitize(ns):
     for n in ns:
      if n.get('link','').startswith('frontier-'):n.pop('link',None)
      sanitize(n.get('children',[]))
    sanitize(f['children'])
 (P/'scene_design.json').write_text(json.dumps(D,ensure_ascii=False,separators=(',',':')))
 (P/'svg').mkdir(exist_ok=True)
 allframes=[]
 for p in D['pages']:
  for f in p['frames']:
   (P/'svg'/f'{f["id"]}.svg').write_text(svg_frame(f));allframes.append(f)
 runtime=(P/'plugin/runtime.js').read_text()
 (P/'plugin/code.js').write_text('const DESIGN = '+json.dumps(D,ensure_ascii=False,separators=(',',':'))+';\n'+runtime)
 print(f'{len(allframes)} frames created across {len(D["pages"])} design pages; native component library added by plugin.')
 # A local preview is deliberately distinct from Figma. The two share one scene graph.
 options=''.join(f'<optgroup label="{html.escape(p["name"])}">'+''.join(f'<option value="{f["id"]}">{html.escape(f["name"])}</option>' for f in p['frames'])+'</optgroup>' for p in D['pages'])
 svgs={f['id']:svg_frame(f) for f in allframes}
 index='''<!doctype html><html><head><meta charset="utf-8"><title>SHIFTWISE · Design review</title><style>body{margin:0;background:#dce5e9;font-family:Inter,Arial,sans-serif}header{height:64px;background:#102e35;color:white;display:flex;gap:20px;align-items:center;padding:0 24px;position:sticky;top:0;z-index:9}header strong{font-size:18px}select{max-width:520px;padding:10px;border:1px solid #5c8087;border-radius:6px;background:#173b44;color:white}a{color:inherit}main{padding:28px;display:flex;justify-content:center}.canvas{background:white;box-shadow:0 8px 35px #18343d22}svg{display:block;max-width:100%;height:auto}#hint{margin-left:auto;font-size:12px;color:#b2cbd1}button{padding:8px;border:0;border-radius:5px;cursor:pointer}footer{text-align:center;color:#607b84;padding:18px;font-size:12px}</style></head><body><header><strong>SHIFTWISE</strong><select id="screen">'''+options+'''</select><button id="zoom">Fit width</button><span id="hint">Design preview · prepared frames, not live calculations</span></header><main><div class="canvas" id="canvas"></div></main><footer>Editable Figma import package · Native plugin and SVGs supplied · All figures are source-backed model estimates</footer><script>const SCREENS='''+json.dumps(svgs)+''';const select=document.querySelector('#screen'),canvas=document.querySelector('#canvas');function show(id){if(!SCREENS[id])return;select.value=id;canvas.innerHTML=SCREENS[id];location.hash=id;window.scrollTo(0,0)}select.onchange=()=>show(select.value);document.addEventListener('click',e=>{const a=e.target.closest('[data-frame-link]');if(a){e.preventDefault();show(a.dataset.frameLink)}});document.querySelector('#zoom').onclick=()=>{canvas.style.width=canvas.style.width?'':'100%'};show(location.hash.slice(1)||'command');</script></body></html>'''
 (P/'PREVIEW.html').write_text(index)
 (P/'SCREEN_INDEX.json').write_text(json.dumps([{'page':p['name'],'id':f['id'],'name':f['name'],'width':f['width'],'height':f['height']} for p in D['pages'] for f in p['frames']],indent=2))

if __name__=='__main__':main()
