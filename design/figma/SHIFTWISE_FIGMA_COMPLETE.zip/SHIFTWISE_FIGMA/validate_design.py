from pathlib import Path
import json, hashlib, xml.etree.ElementTree as ET
P=Path(__file__).parent
D=json.loads((P/'scene_design.json').read_text())
frames=[f for p in D['pages'] for f in p['frames']];byid={f['id']:f for f in frames}
assert len(frames)==len(byid)==39
framepages={f['id']:p['name'] for p in D['pages'] for f in p['frames']}
issues=[];links=[];native=0;nodes=0

def walk(ns,W,H,path,page):
 global native,nodes
 for n in ns:
  nodes+=1
  if n['type']!='line':
   x=n.get('x',0);y=n.get('y',0);w=n.get('width',0);h=n.get('height',0)
   assert w>0 and h>0,(path,n)
   if x<-.1 or y<-.1 or x+w>W+.5 or y+h>H+.5:issues.append(path+'/'+n.get('name',''))
  if n.get('link'):
   assert n['link'] in byid,n['link']
   assert framepages[n['link']]==page,(path,n['link'])
   links.append(n['link'])
  if n.get('componentKey','').startswith('button.'):native+=1
  if 'children'in n:walk(n['children'],n['width'],n['height'],path+'/'+n.get('name',''),page)
for p in D['pages']:
 for f in p['frames']:
  walk(f['children'],f['width'],f['height'],f['id'],p['name'])
  ET.parse(P/'svg'/f'{f["id"]}.svg')
assert not issues,issues
source=json.loads((P/'source_data.json').read_text());sc={v['id']:v for v in source['scenes']}
assert abs(sc['BASE']['plan']['cost']-6614.46)<1e-6
assert [r['employees'] for r in sc['BASE']['plan']['allocations']]==[35,17,2]
for scene in sc.values():
 a=scene['plan']['allocations']
 assert all(v['regular']+(a[1-i]['flex'] if i<2 else 0)<=v['available_regular'] for i,v in enumerate(a))
assert source['validation']['valid'] and source['validation']['rows']==567
repo=Path('/workspace/casecomp')
sha=hashlib.sha256((repo/'artifacts/TEAM_SUBMISSION_COMPLETED.csv').read_bytes()).hexdigest() if repo.exists() else 'not available outside original workspace'
if repo.exists():assert sha=='910ee279b0f25a720623051b54aebbc4b1148d8b0c0caffa1e6cbc01823bebe6'
report={'artboards':len(frames),'scene_pages':len(D['pages']),'native_plugin_total_pages':3,'scene_nodes':nodes,'prepared_prototype_links':len(links),'screen_button_instances_requested':native,'unresolved_or_cross_page_links':0,'out_of_bounds_nodes':issues,'svg_xml_parsed':len(frames),'source_snapshots_pool_conservation_valid':True,'audited_csv_sha256':sha,'actual_figma_account_import_verified':False,'application_changed':False}
(P/'DESIGN_VERIFICATION.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
